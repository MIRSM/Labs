﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Diagnostics;

namespace STRLAB2
{   public partial class Form1 : Form
    {
        public const int N = 10000000;
        public static int[] ar = new int[N];
        public const int YY = 100;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Stopwatch sw1 = new Stopwatch();
            int i,L,R,TT,p;
            bool f = false;
            long t;
            R = 0;
            p = -1;
            int K = Convert.ToInt32(numericUpDown1.Value);
            sw1.Start();
            for (TT = 0; TT < YY; TT++)
            {
                R = N - 2;
                L = 0;
                p = -1;
                while (R > L)
                {
                    i = (R + L) / 2;
                    if (K == ar[i])
                    {
                        p = i;
                        break;
                    }
                    else if (K > ar[i])
                    {
                        L = i + 1;
                    }
                    else
                    {
                        R = i - 1;
                    }
                }
            }
                    sw1.Stop();
                    t = sw1.ElapsedTicks;
                    textBox2.Text = Convert.ToString(t);
                    if (p==-1)
                    {
                        textBox1.Text = "Не найдено";

                    }
                    else
                    {
                        textBox1.Text = Convert.ToString(p);
                    }
            
            Stopwatch sw2 = new Stopwatch();
            sw2.Start();
            for (TT = 0; TT < YY; TT++)
            {
                L = 0;
                R = N - 2;
                while (R > L)
                {
                    i = (R + L) / 2;
                    if (K <= ar[i])
                    {
                        R = i;
                    }
                    else
                    {
                        L = i + 1;
                    }
                }
            }
                    sw2.Stop();
                    t = sw2.ElapsedTicks;
                    textBox3.Text = Convert.ToString(t);
                    if (ar[R] == K)
                    {
                        textBox4.Text = Convert.ToString(R);
                    }
                    else
                    {
                        //net
                        textBox4.Text = "Не наёдено";
                    }

            Stopwatch sw3 = new Stopwatch();
            ar[N - 1] = K+1;
            sw3.Start();
            i = 0;
                while (K > ar[i])
                {
                    i++;
                }
                sw3.Stop();
                t = sw3.ElapsedTicks;
                textBox5.Text = Convert.ToString(t*YY);
                if (K == ar[i])
                {
                    textBox6.Text = Convert.ToString(i);
                }
                else
                {
                    textBox6.Text = "Не найдено";
                }
            }

        private void Form1_Activated_1(object sender, EventArgs e)
        {
            Random r = new Random();
            ar[0] = r.Next(5);
            for (int i = 1; i < N-1; i++)
            {
                ar[i] = ar[i-1]+r.Next(5);
            }
        }
    }
}
