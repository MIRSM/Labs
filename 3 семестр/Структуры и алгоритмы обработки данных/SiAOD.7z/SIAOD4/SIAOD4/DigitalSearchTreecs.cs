﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DigitalSearch
{
    //бор
    class DigitalSearchTree
    {
        public DigitalSearchTree() { }

        //первый узел дерева(корень)
        private NodeOfDSTree root = null;

        //возвращает узел который содержит val
        //если ни один узел не содержит val, возвращает null
        //принимает элемент на начало списка nodeOfDSTree, и символ val
        private NodeOfDSTree SearchRight(NodeOfDSTree nodeOfDSTree, char val)
        {
            while (nodeOfDSTree.Right != null && nodeOfDSTree.Right.Val != val)
                nodeOfDSTree = nodeOfDSTree.Right;
            return nodeOfDSTree;
        }

        //добавляет вправо узел с символом val, после nodeOfDSTree и возвращет новый узел
        private NodeOfDSTree AddCharRight(NodeOfDSTree nodeOfDSTree, char val)
        {
            nodeOfDSTree.Right = new NodeOfDSTree(val);
            return nodeOfDSTree.Right;
        }

        //добавляет вниз узел с символом val, после nodeOfDSTree и возвращет новый узел
        private NodeOfDSTree AddCharDown(NodeOfDSTree nodeOfDSTree, char val)
        {
            nodeOfDSTree.Down = new NodeOfDSTree(val);
            return nodeOfDSTree.Down;
        }
       
        //осуществляет поиск совпадающей части слова s, начиная с позиции i и узла nodeOfDSTree
        private bool SearchOfMatchingPart(string s, ref int i, ref NodeOfDSTree nodeOfDSTree)
        {
            while (i < s.Length)
            {
                if (nodeOfDSTree.Val != s[i])
                {
                    nodeOfDSTree = SearchRight(nodeOfDSTree, s[i]);
                    if (nodeOfDSTree.Right == null) return false;
                    nodeOfDSTree = nodeOfDSTree.Right;
                }
                if (nodeOfDSTree.Down != null)
                {
                    nodeOfDSTree = nodeOfDSTree.Down;
                }
                i++;
            }
            return true;
        }

        //добавляет слово в бор
        //возвращает удалось ли добавить слово в бор
        public bool AddWord(string s)
        {
            int i = 0;
            if (root == null) root = new NodeOfDSTree(s[i]);
            NodeOfDSTree nodeOfDSTree = root;

            //поиск совпадающей части
            if (SearchOfMatchingPart(s, ref i, ref nodeOfDSTree)) return false;
            
            //добавление первого несовпадающего символа вправо
            nodeOfDSTree = AddCharRight(nodeOfDSTree, s[i]);
            i++;

            //добавление оставшихся символов вниз
            while(i < s.Length)
            {
                nodeOfDSTree = AddCharDown(nodeOfDSTree, s[i]);
                i++;
            }

            return true;
            
        }

        //возвращает содержится ли слово s в боре
        public bool Contains(string s)
        {
            NodeOfDSTree nodeOfDSTree = root;
            int i = 0;
            return (root != null && SearchOfMatchingPart(s, ref i, ref nodeOfDSTree));
        }


    }
}
