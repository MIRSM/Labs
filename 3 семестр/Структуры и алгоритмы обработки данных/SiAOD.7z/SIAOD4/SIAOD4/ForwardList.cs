﻿namespace CompareOfHash
{
    //бор
    class ForwardList
    {

        //узел списка
        public class Node
        {
            //указатель на следующий узел
            private Node next = null;
            public Node Next { get { return next; } set { next = value; } }

            //указатель на правый узел
            private Node right = null;
            public Node Right { get { return right; } set { right = value; } }
            
            //значение узла
            private char val;
            public char Val { get { return val; } set { val = value; } }

            //конструктор
            public Node(char val)
            {
                Val = val;
            }
            public Node() { }
            
        }
        

        //конструктор
        public ForwardList() {}

        //первый узел дерева
        public Node root = null;

        //возвращает узел который содержит val
        //если ни один узел не содержит val, возвращает null
        //принимает элемент на начало списка Node, и символ val
        private Node SearchRight(Node FList, char val)
        {
            while (FList.Right != null && FList.Right.Val != val)
                FList = FList.Right;
            return FList;
        }
    
        //осуществляет поиск совпадающей части слова s, начиная с позиции i и узла Node
        private bool SearchOfMatchingPart(string s, ref int i, ref Node FList)
        {
            while (i < s.Length)
            {
                if (FList.Val != s[i])
                {
                    FList = SearchRight(FList, s[i]);
                    if (FList.Right == null) return false;
                    FList = FList.Right;
                }
                if (FList.Next != null)
                {
                    FList = FList.Next;
                }
                i++;
            }
            return true;
        }

        //добавляет слово в дерево
        //возвращает удалось ли добавить слово в дерево
        public bool AddWord(string s)
        {
            int i = 0;
            if (root == null) root = new Node(s[i]);
            Node Node = root;

            //поиск совпадающей части
            if (SearchOfMatchingPart(s, ref i, ref Node)) return false;

            //добавление первого несовпадающего символа вправо
            Node = RPush(Node, s[i]);
            i++;

            //добавление оставшихся символов вниз
            while (i < s.Length)
            {
                Node = Push(Node, s[i]);
                i++;
            }

            return true;

        }

        //возвращает содержится ли слово s в дереве
        public bool Contains(string s)
        {
            Node FList = root;
            int i = 0;
            return (root != null && SearchOfMatchingPart(s, ref i, ref FList));
        }

        //добавление элемента снизу
        public Node Push(Node FList, char val) {
            FList.Next = new Node(val);
            return FList.Next;
        }

        //добавление элемента справа
        public Node RPush(Node FList, char val)
        {
            FList.Right = new Node(val);
            return FList.Right;
        }

    }
}
