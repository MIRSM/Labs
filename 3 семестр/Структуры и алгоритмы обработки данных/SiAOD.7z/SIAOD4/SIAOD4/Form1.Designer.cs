﻿namespace SIAOD4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.InText = new System.Windows.Forms.TextBox();
            this.InBut = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.FBut = new System.Windows.Forms.Button();
            this.FText = new System.Windows.Forms.TextBox();
            this.RText = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.LBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // InText
            // 
            this.InText.Location = new System.Drawing.Point(161, 56);
            this.InText.Name = "InText";
            this.InText.Size = new System.Drawing.Size(95, 20);
            this.InText.TabIndex = 0;
            // 
            // InBut
            // 
            this.InBut.Location = new System.Drawing.Point(66, 52);
            this.InBut.Name = "InBut";
            this.InBut.Size = new System.Drawing.Size(67, 27);
            this.InBut.TabIndex = 1;
            this.InBut.Text = "Добавить";
            this.InBut.UseVisualStyleBackColor = true;
            this.InBut.Click += new System.EventHandler(this.InBut_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(61, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(246, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Добавление в список";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(61, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Поиск в списке";
            // 
            // FBut
            // 
            this.FBut.Location = new System.Drawing.Point(66, 176);
            this.FBut.Name = "FBut";
            this.FBut.Size = new System.Drawing.Size(67, 23);
            this.FBut.TabIndex = 3;
            this.FBut.Text = "Найти";
            this.FBut.UseVisualStyleBackColor = true;
            this.FBut.Click += new System.EventHandler(this.FBut_Click);
            // 
            // FText
            // 
            this.FText.Location = new System.Drawing.Point(156, 179);
            this.FText.Name = "FText";
            this.FText.Size = new System.Drawing.Size(100, 20);
            this.FText.TabIndex = 2;
            // 
            // RText
            // 
            this.RText.Location = new System.Drawing.Point(156, 220);
            this.RText.Name = "RText";
            this.RText.ReadOnly = true;
            this.RText.Size = new System.Drawing.Size(100, 20);
            this.RText.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(25, 218);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Результат: ";
            // 
            // LBox
            // 
            this.LBox.FormattingEnabled = true;
            this.LBox.Location = new System.Drawing.Point(372, 52);
            this.LBox.Name = "LBox";
            this.LBox.Size = new System.Drawing.Size(105, 147);
            this.LBox.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 327);
            this.Controls.Add(this.LBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.RText);
            this.Controls.Add(this.FText);
            this.Controls.Add(this.FBut);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.InBut);
            this.Controls.Add(this.InText);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox InText;
        private System.Windows.Forms.Button InBut;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button FBut;
        private System.Windows.Forms.TextBox FText;
        private System.Windows.Forms.TextBox RText;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox LBox;
    }
}

