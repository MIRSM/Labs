﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CompareOfHash;

namespace SIAOD4
{
    public partial class Form1 : Form
    {
        ForwardList FList = new ForwardList();
        public Form1()
        {
            InitializeComponent();
        }

        private void InBut_Click(object sender, EventArgs e)
        {
            string key = Convert.ToString(InText.Text);
            ForwardList N = FList;
            InText.Text = "";
            string key1 = key + "*";
            N.AddWord("*");
            if (!N.Contains(key1))
            {
                N.AddWord(key1);
                key += "\t\n";
                LBox.Items.Add(key);
            }
            else
            {
                MessageBox.Show("Слово дублируется!");
            }
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            
        }

        private void FBut_Click(object sender, EventArgs e)
        { 
            string key = Convert.ToString(FText.Text);
            ForwardList M = FList;
            FText.Text = "";
            key += "*";
            if (M.Contains(key))
                RText.Text = "Слово найдено!";
            else
                RText.Text = "Слово не найдено!";
        }
    }
}
