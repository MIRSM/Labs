﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIAOD5
{
    public partial class Form1 : Form
    {
        TextBox[,] textboxl = new TextBox[11, 11];
        TextBox[,] textboxt = new TextBox[11, 11];
        TextBox[,] textboxc = new TextBox[11, 11];
        TextBox[,] textboxi = new TextBox[11, 11];
        TextBox[,] textboxs = new TextBox[21, 11];
        TextBox[,] textboxcom = new TextBox[4, 6];
        Random rand = new Random();
        public int Comp;
        public int Chan;
        public Form1()
        {

            InitializeComponent();

        }

        //Линейная сортировка
        public void LinS(int[] Aar,int N,bool che)
        {

            int[] Bar = new int[N];

            for (int j = 1; j < N; j++)
            {
                Bar[Aar[j]] += 1;
                if (che)
                {
                    textboxl[j, 0].Text = Aar[j].ToString();
                    textboxl[j, 0].ForeColor = Color.Red;
                    textboxl[j, 0].BackColor = Color.Black;
                }
            }

            int k = 0;
            if (che)
            {
                textboxl[0, 2].Text = "2";
                textboxl[0, 2].BackColor = Color.Black;
                textboxl[0, 2].ForeColor = Color.Red;
            }
            for (int i = 1; i < N; i++)
            {
                int j = Bar[i];
                while (j != 0)
                {
                    Aar[k] = i;
                    if (che)
                        textboxl[k + 1, 2].Text = Aar[k].ToString();
                    k += 1;
                    j -= 1;
                }
                if (che)
                    textboxl[i, 1].Text = Bar[i].ToString();
            }
        }

        private void LinBut_Click(object sender, EventArgs e)
        {
            bool che = true;
            int[] Aar = new int[11];
            int[] Bar = new int[11];
            for (int i = 0; i < 10; i++) Bar[i] = 0;
            textboxl[0, 1].Text = "1";
            textboxl[0, 1].BackColor = Color.Black;
            textboxl[0, 1].ForeColor = Color.Red;
            for (int j = 1; j < 11; j++)
            {
                Aar[j] = rand.Next(1, 11);
            }
            LinS(Aar, 11,che);
        }


        //Запуск формы

        private void Form1_Shown(object sender, EventArgs e)
        {
            for (int i = 0; i < 11; i++)
            {
                for (int j = 0; j < 11; j++)
                {
                    textboxl[i, j] = new TextBox();
                    tableLayoutPanel1.Controls.Add(textboxl[i, j], i, j);
                    textboxt[i, j] = new TextBox();
                    tableLayoutPanel2.Controls.Add(textboxt[i, j], i, j);
                    textboxc[i, j] = new TextBox();
                    tableLayoutPanel3.Controls.Add(textboxc[i, j], i, j);
                    textboxi[i, j] = new TextBox();
                    tableLayoutPanel4.Controls.Add(textboxi[i, j], i, j);
                }
            }
            for (int i = 0; i < 11; i++)
            {
                for (int j = 0; j < 21; j++)
                {

                    textboxs[j, i] = new TextBox();
                    tableLayoutPanel5.Controls.Add(textboxs[j, i], j, i);
                }
            }
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 6; j++)
                {

                    textboxcom[i, j] = new TextBox();
                    tableLayoutPanel6.Controls.Add(textboxcom[i, j], i, j);
                }
            }
            textboxcom[1, 0].Text = "Сравнения";
            textboxcom[1, 0].BackColor = Color.Black;
            textboxcom[1, 0].ForeColor = Color.Red;
            textboxcom[2, 0].Text = "Перестановки";
            textboxcom[2, 0].BackColor = Color.Black;
            textboxcom[2, 0].ForeColor = Color.Red;
            textboxcom[3, 0].Text = "Время";
            textboxcom[3, 0].BackColor = Color.Black;
            textboxcom[3, 0].ForeColor = Color.Red;
            textboxcom[0, 1].Text = "Обмен";
            textboxcom[0, 1].BackColor = Color.Black;
            textboxcom[0, 1].ForeColor = Color.Red;
            textboxcom[0, 2].Text = "Выбор";
            textboxcom[0, 2].BackColor = Color.Black;
            textboxcom[0, 2].ForeColor = Color.Red;
            textboxcom[0, 3].Text = "Включения";
            textboxcom[0, 3].BackColor = Color.Black;
            textboxcom[0, 3].ForeColor = Color.Red;
            textboxcom[0, 4].Text = "Шелла";
            textboxcom[0, 4].BackColor = Color.Black;
            textboxcom[0, 4].ForeColor = Color.Red;
            textboxcom[0, 5].Text = "Линейная";
            textboxcom[0, 5].BackColor = Color.Black;
            textboxcom[0, 5].ForeColor = Color.Red;
        }

        //Обмен
        public void TraS(int[] Aar, int N,bool che)
        {
            Comp = 0;
            Chan = 0;

            int j = 1;

            bool f = false;
            int x;

            while (!f)
            {
                bool g = true;

                for (int i = 1; i < N - 1; i++)
                {
                    if (!che) Comp++; 
                    if (Aar[i] > Aar[i + 1])
                    {
                        if (!che) Chan++;
                        x = Aar[i + 1];
                        Aar[i + 1] = Aar[i];
                        Aar[i] = x;
                        g = false;
                    }
                }

                
                if (che)
                {
                    for (int r = 1; r < 11; r++)
                        textboxt[r, j].Text = Aar[r].ToString();

                    textboxt[0, j].Text = (j).ToString();
                    textboxt[0, j].ForeColor = Color.Red;
                    textboxt[0, j].BackColor = Color.Black;
                }
                if (g) break;
                j += 1;
                N -= 1;
            }
        }

        private void TraBut_Click(object sender, EventArgs e)
        {
            bool che = true;
            for (int i = 0; i < 11; i++)
                for (int r = 0; r < 11; r++)
                {
                    textboxt[r, i].BackColor = Color.White;
                    textboxt[r, i].Text = "";
                }

            int N = 11;
            int[] Aar = new int[N];

            for (int t = 1; t < N; t++)
            {
                Aar[t] = rand.Next(100);
                textboxt[t, 0].Text = Aar[t].ToString();
                textboxt[t, 0].ForeColor = Color.Red;
                textboxt[t, 0].BackColor = Color.White;
            }
            TraS(Aar, N,che);
        }

         //Выбор
         public void ChuS(int[] Aar,int N,bool che)
        {
            Comp = 0;
            Chan = 0;

            int x;
            int j = 1;
            int m = N;
            for (int z = 1; z < m - 1; z++)
            {
                int max = 0;
                for (int i = 1; i < N; i++)
                {
                    if(!che) Comp++;
                    if (Aar[i] > max)
                    {
                        max = Aar[i];
                        j = i;
                    }
                }
                if(!che) Chan++;
                x = Aar[N - 1];
                Aar[N - 1] = max;
                Aar[j] = x;
                if (che)
                {
                    for (int r = 1; r < 11; r++)
                        textboxc[r, z].Text = Aar[r].ToString();

                    textboxc[0, z].Text = (z).ToString();
                    textboxc[0, z].ForeColor = Color.Red;
                    textboxc[0, z].BackColor = Color.White;
                }
                N -= 1;
            }
        }

        private void ChuBut_Click(object sender, EventArgs e)
        {
            bool che = true;
            for (int i = 0; i < 11; i++)
                for (int r = 0; r < 11; r++)
                {
                    textboxc[r, i].BackColor = Color.White;
                    textboxc[r, i].Text = "";
                }

            int N = 11;
            int[] Aar = new int[N];


            for (int t = 1; t < N; t++)
            {
                Aar[t] = rand.Next(100);
                textboxc[t, 0].Text = Aar[t].ToString();
                textboxc[t, 0].ForeColor = Color.Red;
                textboxc[t, 0].BackColor = Color.White;
            }
            ChuS(Aar, N,che);
        }

        //Включения
        public void IncS(int[] Aar,int N,bool che)
        {
            Comp = 0;
            Chan = 0;

            for (int i = 2; i < N; i++)
            {
                bool d = false;
                int k = i - 1;
                Aar[0] = Aar[i];

                if (!che) Chan++;
                do
                {

                    if (Aar[k] >= Aar[0])
                    {
                        if (!che) Comp++;
                        Aar[k + 1] = Aar[k];
                    }
                    else break;
                } while (k-- > 0);
                k++;
                Aar[k] = Aar[0];
                if (che)
                {
                    for (int r = 1; r < 11; r++)
                        textboxi[r, i - 1].Text = Aar[r].ToString();

                    textboxi[0, i - 1].Text = (i - 1).ToString();
                    textboxi[0, i - 1].ForeColor = Color.Red;
                    textboxi[0, i - 1].BackColor = Color.White;
                }
            }
        }

        private void IncBut_Click(object sender, EventArgs e)
        {
            bool che = true;
            for (int i = 0; i < 11; i++)
                for (int r = 0; r < 11; r++)
                {
                    textboxi[r, i].BackColor = Color.White;
                    textboxi[r, i].Text = "";
                }

            int N = 11;
            int[] Aar = new int[N];

            for (int t = 1; t < N; t++)
            {
                Aar[t] = rand.Next(100);
                textboxi[t, 0].Text = Aar[t].ToString();
                textboxi[t, 0].ForeColor = Color.Red;
                textboxi[t, 0].BackColor = Color.White;
            }
            IncS(Aar, N,che);

         }

        //Шелла
        public void SheS(int[] Aar, int N, bool che)
        {
            Comp = 0;
            Chan = 0;

            int w = 1;
            int c = 2;
            int h = 1;
            while (c <= N)
            {
                c *= 2;
                h++;
            }
            h--;
            int x = 1;
            for (int s = h; s > 1; s--)
            {
                x = (2 * x) + 1;
            }
            while (x >= 1)
            {
                for (int j = 1 + x; j < N; j++)
                {
                    int a = (j - x);
                    Aar[0] = Aar[j];
                    do
                    {
                        if (!che) Comp++;
                        if (Aar[a] > Aar[0])
                        {
                            if (!che) Chan++;
                            Aar[a + x] = Aar[a];
                            Aar[a] = Aar[0];
                        }
                        else break;
                    } while ((a-=x )> 0);
                }
                if (che)
                {
                    for (int r = 1; r < 21; r++)
                        textboxs[r, w].Text = Aar[r].ToString();

                    textboxs[0, w].Text = (w).ToString();
                    textboxs[0, w].ForeColor = Color.Red;
                    textboxs[0, w].BackColor = Color.White;
                    w++;
                }
                x /= 2;
            }
            }

        private void SHelBut_Click(object sender, EventArgs e)
        {
            bool che = true;
            for (int i = 0; i < 11; i++)
                for (int r = 0; r < 21; r++)
                {
                    textboxs[r, i].BackColor = Color.White;
                    textboxs[r, i].Text = "";
                }

            int N = 21;
            int[] Aar = new int[N];
            
            for (int t = 1; t < N; t++)
            {
                Aar[t] = rand.Next(100);
                textboxs[t, 0].Text = Aar[t].ToString();
                textboxs[t, 0].ForeColor = Color.Red;
                textboxs[t, 0].BackColor = Color.Black;
            }
            SheS(Aar, N, che);
        }

        //Характеристики

        private void ComBut_Click(object sender, EventArgs e)
        {
            int N = Convert.ToInt32(numericUpDown1.Value)+1;
            int[] Aar = new int[N];
            int[] Aar1 = new int[N];
            int[] Aar2 = new int[N];
            int[] Aar3 = new int[N];
            int[] Aar4 = new int[N];
            int[] Aar5 = new int[N];
            bool che = false;

            for (int t = 1; t < N; t++)
            {
                Aar[t] = rand.Next(N);
                Aar1[t] = Aar[t];
                Aar2[t] = Aar[t];
                Aar3[t] = Aar[t];
                Aar4[t] = Aar[t];
                Aar5[t] = Aar[t];
            }

            //Обмен

              {
                Stopwatch sw1 = new Stopwatch();
                sw1.Start();
                TraS(Aar1, N, che);
                sw1.Stop();
                long t = sw1.ElapsedTicks;
                textboxcom[1, 1].Text = Comp.ToString();
                textboxcom[2, 1].Text = Chan.ToString();
                textboxcom[3, 1].Text = t.ToString();
            }

            //Выбор
            
            {
                Stopwatch sw2 = new Stopwatch();
                sw2.Start();
                ChuS(Aar2,N,che);
                sw2.Stop();
                long t = sw2.ElapsedTicks;
                textboxcom[1, 2].Text = Comp.ToString();
                textboxcom[2, 2].Text = Chan.ToString();
                textboxcom[3, 2].Text = t.ToString();
            }

            //Включения
            
            {
                Stopwatch sw3 = new Stopwatch();
                sw3.Start();
                IncS(Aar3, N, che);
                sw3.Stop();
                long t = sw3.ElapsedTicks;
                textboxcom[1, 3].Text = Comp.ToString();
                textboxcom[2, 3].Text = Chan.ToString();
                textboxcom[3, 3].Text = t.ToString();
            }

            //Шелла

            {
                Stopwatch sw4 = new Stopwatch();
                sw4.Start();
                SheS(Aar4, N, che);
                sw4.Stop();
                long t = sw4.ElapsedTicks;
                textboxcom[1, 4].Text = Comp.ToString();
                textboxcom[2, 4].Text = Chan.ToString();
                textboxcom[3, 4].Text = t.ToString();
            }

            //Линейная
            {
                Stopwatch sw5 = new Stopwatch();
                sw5.Start();
                LinS(Aar5, N, che);
                sw5.Stop();
                long t = sw5.ElapsedTicks;
                textboxcom[3, 5].Text = t.ToString();
            }

        }
    }
}
