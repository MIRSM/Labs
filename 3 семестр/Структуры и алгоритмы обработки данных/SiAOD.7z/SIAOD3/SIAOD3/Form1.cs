﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using CompareOfHash;

namespace SIAOD3
{
    public partial class Form1 : Form
    {
        public const int M = 10000;
        public const int N = 1000;
        public int k;
        public int s;
        public int[] mas = new int[N];
        public int[] mass = new int[M];
        public int[] mass2 = new int[M];
        public const double A = 0.618033;
        ForwardList[] masLis= new ForwardList [M];
        public int[] masOp = new int[M];
        public void cCha(int[] mas)
        {
            for (int i = 0; i < M; i++)
            {
                int r = 0;
                int f = mas[i];
                while (f > 0)
                {
                    r += (f % (M));
                    f /= (M);
                }
                r = r % M;
                masLis[r].Push(mas[i]);
            }
        }
        public void cOpe(int[] mas)
        {
            for (int i = 0; i < M; i++)
            {
                masOp[i] = -1;
            }
            for (int i = 0; i < M; i++)
            {
                int r = 0;
                int f = mas[i];
                while (f > 0)
                {
                    r += (f % M);
                    f /= M;
                }
                r = r % M;
                if (masOp[r] == -1)
                    masOp[r]= mas[i];
                else
                {
                    bool d = false;
                    int j;
                    for (j=r+1; j < M; j++)
                    {
                        if (masOp[j] == -1)
                        {
                            masOp[j] = mas[i];
                            d = true;
                            break;
                        }
                    }
                    if (!d)
                    {
                        for (j = 0; j < r; j++)
                        {
                            if (masOp[j] == -1)
                            {
                                masOp[j] = mas[i];
                                d = true;
                                break;
                            }
                        }
                    }
                }
                    
            }
        }
        public void fOpe(int[] mas)
        {
            k = 0;
            s = 0;
            for(int i = 0; i < M; i++)
            {
                int r = 0;
                int f = mas[i];
                while (f > 0)
                {
                    r += (f % M);
                    f /= M;
                }
                r = r % M;
                k++;
                if (mas[i] == masOp[r])
                {
                    s++;
                }
                else
                {
                    bool d = false;
                    for (int j = r + 1; j < M; j++)
                    {
                        k++;
                        if (mas[i] == masOp[j])
                        {
                            s++;
                            d = true;
                            break;
                        }
                    }
                    if (!d)
                    {
                        for(int j = 0; j < r; j++)
                        {
                            k++;
                            if (mas[i] == masOp[j])
                            {
                                s++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        public void  fCha(int[] mas)
        {
            k = 0;
            s = 0;
            for (int i = 0; i < M; i++)
            {
                int r = 0;
                int a = mas[i];
                while (a > 0)
                {
                    r += (a % M);
                    a /= M;
                }
                r = r % M;
                if (masLis[r].Begin == null) k++;
                else
                {
                        for (ForwardList.Node j = masLis[r].Begin; j != null; j++)
                        {
                            k++;
                            if (j.Val == mas[i])
                            {
                                s++;
                                break;
                            }
                        }
                }
            }
        }
        public class Str
        {
            public static int nDiv = 0;
            public static int nMid = 0;
            public static int nIn = 0;
            public static int nMul = 0;
            public int sDiv;
            public int sMid;
            public int sIn;
            public int sMul;

            public Str(){
                sDiv = 0;
                sMid = 0;
                sMul = 0;
                sIn = 0;
                
            }
            public void fDiv(int[] mas)
            {

                ForwardList[] masClass = new ForwardList[N];
                for (int i = 0; i < N; i++)
                {
                    masClass[i] = new ForwardList();
                }
                for (int i = 0; i < N; i++)
                {
                    masClass[(mas[i] % 997) + 1].Push(mas[i]);
                    if (masClass[(mas[i] % 997) + 1].Size > 1)
                        sDiv++;
                }
            }
            public void fMid(int[] mas)
            {
                ForwardList[] masClass = new ForwardList[N];
                for (int i = 0; i < N; i++)
                {
                    masClass[i] = new ForwardList();
                }
                for (int i = 0; i < N; i++)
                {
                    int c = 0;
                    long f = Convert.ToInt64(mas[i])* Convert.ToInt64(mas[i]);
                    while (f > 0)
                    {
                        f /= 10;
                            
                        c++;
                    }
                    f= Convert.ToInt64(mas[i]) * Convert.ToInt64(mas[i]);
                    f = f / ((int)Math.Pow(10.0, Math.Abs(((c - 3) / 2))));
                    f = f % (int)Math.Pow(10.0, 3.0);
                    masClass[f].Push(mas[i]);
                    if (masClass[f].Size > 1)
                        sMid++;
                    
                }
            }
            public void fIn(int[] mas)
            {
                ForwardList[] masClass = new ForwardList[N];
                for (int i = 0; i < N; i++)
                {
                    masClass[i] = new ForwardList();
                }
                for (int i = 0; i < N; i++)
                {
                    int r = 0;
                    int f = mas[i];
                    while (f>0)
                    {
                        r += (f % (N));
                        f /= (N);
                    }
                    r = r % N;
                    masClass[r].Push(mas[i]);
                    if (masClass[r].Size > 1)
                     sIn++;
                }
            }
            public void fMul(int[] mas)
            {
                ForwardList[] masClass = new ForwardList[N];
                for (int i = 0; i < N; i++)
                {
                    masClass[i] = new ForwardList();
                }
                for (int i = 0; i < N; i++)
                {
                    double D = 1.0*mas[i] * A;
                    D = D- (long)(D);
                    int H = (int)(D*N);
                    masClass[H].Push(mas[i]);
                    if (masClass[H].Size > 1)
                        sMul++;
                }
            }

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            
        }

        private void butCalc1_Click(object sender, EventArgs e)
        {
            Str.nDiv = 0;
            Str.nIn = 0;
            Str.nMid = 0;
            Str.nMul = 0;
            for (int i = 0; i < Convert.ToInt64(numericUpDown1.Value); i++)
            {
                Random r = new Random();
                for (int j = 0; j < N; j++)
                {
                    mas[j] = r.Next(65000);
                }
                Str str1 = new Str();
                str1.fDiv(mas);
                str1.fMid(mas);
                str1.fIn(mas);
                str1.fMul(mas);
                if (Math.Min(Math.Min(str1.sDiv, str1.sIn), Math.Min(str1.sMid, str1.sMul)) == str1.sDiv)
                    Str.nDiv++;
                if (Math.Min(Math.Min(str1.sDiv, str1.sIn), Math.Min(str1.sMid, str1.sMul)) == str1.sIn)
                    Str.nIn++;
                if (Math.Min(Math.Min(str1.sDiv, str1.sIn), Math.Min(str1.sMid, str1.sMul)) == str1.sMid)
                    Str.nMid++;
                if (Math.Min(Math.Min(str1.sDiv, str1.sIn), Math.Min(str1.sMid, str1.sMul)) == str1.sMul)
                    Str.nMul++;
            }
            textDiv.Text = Convert.ToString(Str.nDiv);
            textMid.Text = Convert.ToString(Str.nMid);
            textIn.Text = Convert.ToString(Str.nIn);
            textMul.Text = Convert.ToString(Str.nMul);
        }

        private void butCalc2_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            for (int i = 0; i < M; i++)
            {
                mass[i] = r.Next(M);
                masLis[i] = new ForwardList();
                mass2[i] = r.Next(2 * M);
            }
            cOpe(mass);
            Stopwatch sw1 = new Stopwatch();
            sw1.Start();
            fOpe(mass2);
            sw1.Stop();
            long t1 = sw1.ElapsedTicks;//Время Откр
            textOpeT.Text = Convert.ToString(t1);
            textOpeF.Text = Convert.ToString(s);
            textOpeN.Text = Convert.ToString(1.0*k/M);
            cCha(mass);
            Stopwatch sw2 = new Stopwatch();
            sw2.Start();
            fCha(mass2);
            sw2.Stop();
            long t2 = sw2.ElapsedTicks;
            textChaT.Text = Convert.ToString(t2);
            textChaF.Text = Convert.ToString(s);
            textChaN.Text = Convert.ToString(1.0*k/M);
        }
    }
}
