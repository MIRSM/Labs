﻿namespace CompareOfHash
{
    //односвязный список
    class ForwardList
    {

        //узел односвязного списка
        public class Node
        {
            //указатель на следующий узел
            private Node next = null;
            public Node Next { get { return next; } set { next = value; } }

            //значение узла
            private int val = 0;
            public int Val { get { return val; } set { val = value; } }

            //конструктор
            public Node(int val = 0)
            {
                this.val = val;
            }

            //получение следующего узла
            public static Node operator ++(Node Node1)
            {
                return Node1.next;
            }
        }

        //размер списка
        private int size = 0;
        public int Size { get { return size; } }

        //узел, который является началом списка
        private Node begin = new Node();
        public Node Begin { get { return begin.Next;}
            set { begin = value; } }

        //узел, который ялвяется концом списка
        private Node end = null;
        internal Node End { get { return end; }
            set { end = value; } }

        //конструктор
        public ForwardList() {
            End = begin;
        }

        //добавление элемента списка
        public void Push(int val) {
            End.Next = new Node(val);
            End++;
            size++;
        }

    }
}
