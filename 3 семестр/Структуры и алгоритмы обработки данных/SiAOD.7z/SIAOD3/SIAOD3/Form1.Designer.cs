﻿using System;

namespace SIAOD3
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textDiv = new System.Windows.Forms.TextBox();
            this.textMid = new System.Windows.Forms.TextBox();
            this.textIn = new System.Windows.Forms.TextBox();
            this.textMul = new System.Windows.Forms.TextBox();
            this.butCalc1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.butCalc2 = new System.Windows.Forms.Button();
            this.textChaT = new System.Windows.Forms.TextBox();
            this.textOpeT = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textOpeN = new System.Windows.Forms.TextBox();
            this.textOpeF = new System.Windows.Forms.TextBox();
            this.textChaN = new System.Windows.Forms.TextBox();
            this.textChaF = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Кол-во сравнений:";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(471, 21);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(100, 20);
            this.numericUpDown1.TabIndex = 1;
            this.numericUpDown1.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Метод деления:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(12, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(270, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Метод середины квадратов:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(12, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(199, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = "Метод свертывания:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(12, 205);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(181, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = "Метод умножения:";
            // 
            // textDiv
            // 
            this.textDiv.Location = new System.Drawing.Point(471, 73);
            this.textDiv.Name = "textDiv";
            this.textDiv.ReadOnly = true;
            this.textDiv.Size = new System.Drawing.Size(100, 20);
            this.textDiv.TabIndex = 6;
            this.textDiv.TextChanged += new System.EventHandler(this.textDiv_TextChanged);
            // 
            // textMid
            // 
            this.textMid.Location = new System.Drawing.Point(471, 117);
            this.textMid.Name = "textMid";
            this.textMid.ReadOnly = true;
            this.textMid.Size = new System.Drawing.Size(100, 20);
            this.textMid.TabIndex = 7;
            this.textMid.TextChanged += new System.EventHandler(this.textMid_TextChanged);
            // 
            // textIn
            // 
            this.textIn.Location = new System.Drawing.Point(471, 164);
            this.textIn.Name = "textIn";
            this.textIn.ReadOnly = true;
            this.textIn.Size = new System.Drawing.Size(100, 20);
            this.textIn.TabIndex = 8;
            this.textIn.TextChanged += new System.EventHandler(this.textIn_TextChanged);
            // 
            // textMul
            // 
            this.textMul.Location = new System.Drawing.Point(471, 209);
            this.textMul.Name = "textMul";
            this.textMul.ReadOnly = true;
            this.textMul.Size = new System.Drawing.Size(100, 20);
            this.textMul.TabIndex = 9;
            this.textMul.TextChanged += new System.EventHandler(this.textMul_TextChanged);
            // 
            // butCalc1
            // 
            this.butCalc1.Location = new System.Drawing.Point(242, 249);
            this.butCalc1.Name = "butCalc1";
            this.butCalc1.Size = new System.Drawing.Size(98, 27);
            this.butCalc1.TabIndex = 10;
            this.butCalc1.Text = "Вычислить";
            this.butCalc1.UseVisualStyleBackColor = true;
            this.butCalc1.Click += new System.EventHandler(this.butCalc1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(12, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(328, 24);
            this.label6.TabIndex = 11;
            this.label6.Text = "Метод открытой адресации(В,С,Н):";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.butCalc1);
            this.panel1.Controls.Add(this.textMul);
            this.panel1.Controls.Add(this.textIn);
            this.panel1.Controls.Add(this.textMid);
            this.panel1.Controls.Add(this.textDiv);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.numericUpDown1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(600, 283);
            this.panel1.TabIndex = 12;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textChaF);
            this.panel2.Controls.Add(this.textChaN);
            this.panel2.Controls.Add(this.textOpeF);
            this.panel2.Controls.Add(this.textOpeN);
            this.panel2.Controls.Add(this.butCalc2);
            this.panel2.Controls.Add(this.textChaT);
            this.panel2.Controls.Add(this.textOpeT);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Location = new System.Drawing.Point(0, 282);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(600, 111);
            this.panel2.TabIndex = 13;
            // 
            // butCalc2
            // 
            this.butCalc2.Location = new System.Drawing.Point(242, 84);
            this.butCalc2.Name = "butCalc2";
            this.butCalc2.Size = new System.Drawing.Size(98, 27);
            this.butCalc2.TabIndex = 11;
            this.butCalc2.Text = "Вычислить";
            this.butCalc2.UseVisualStyleBackColor = true;
            this.butCalc2.Click += new System.EventHandler(this.butCalc2_Click);
            // 
            // textChaT
            // 
            this.textChaT.Location = new System.Drawing.Point(369, 44);
            this.textChaT.Name = "textChaT";
            this.textChaT.ReadOnly = true;
            this.textChaT.Size = new System.Drawing.Size(54, 20);
            this.textChaT.TabIndex = 13;
            this.textChaT.TextChanged += new System.EventHandler(this.textChaT_TextChanged);
            // 
            // textOpeT
            // 
            this.textOpeT.Location = new System.Drawing.Point(369, 9);
            this.textOpeT.Name = "textOpeT";
            this.textOpeT.ReadOnly = true;
            this.textOpeT.Size = new System.Drawing.Size(54, 20);
            this.textOpeT.TabIndex = 11;
            this.textOpeT.TextChanged += new System.EventHandler(this.textOpeT_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(12, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(214, 24);
            this.label7.TabIndex = 12;
            this.label7.Text = "Метод цепочек(В,С,Н):";
            // 
            // textOpeN
            // 
            this.textOpeN.Location = new System.Drawing.Point(443, 8);
            this.textOpeN.Name = "textOpeN";
            this.textOpeN.ReadOnly = true;
            this.textOpeN.Size = new System.Drawing.Size(54, 20);
            this.textOpeN.TabIndex = 14;
            // 
            // textOpeF
            // 
            this.textOpeF.Location = new System.Drawing.Point(517, 9);
            this.textOpeF.Name = "textOpeF";
            this.textOpeF.ReadOnly = true;
            this.textOpeF.Size = new System.Drawing.Size(54, 20);
            this.textOpeF.TabIndex = 15;
            this.textOpeF.TextChanged += new System.EventHandler(this.textOpeF_TextChanged);
            // 
            // textChaN
            // 
            this.textChaN.Location = new System.Drawing.Point(443, 44);
            this.textChaN.Name = "textChaN";
            this.textChaN.ReadOnly = true;
            this.textChaN.Size = new System.Drawing.Size(54, 20);
            this.textChaN.TabIndex = 16;
            // 
            // textChaF
            // 
            this.textChaF.Location = new System.Drawing.Point(517, 44);
            this.textChaF.Name = "textChaF";
            this.textChaF.ReadOnly = true;
            this.textChaF.Size = new System.Drawing.Size(54, 20);
            this.textChaF.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 405);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        private void textOpeF_TextChanged(object sender, EventArgs e)
        {

        }

        private void textOpeT_TextChanged(object sender, EventArgs e)
        {
        }

        private void textChaT_TextChanged(object sender, EventArgs e)
        {
        }

        private void textMul_TextChanged(object sender, EventArgs e)
        {

        }

        private void textIn_TextChanged(object sender, EventArgs e)
        {

        }

        private void textMid_TextChanged(object sender, EventArgs e)
        {

        }

        private void textDiv_TextChanged(object sender, EventArgs e)
        {
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textDiv;
        private System.Windows.Forms.TextBox textMid;
        private System.Windows.Forms.TextBox textIn;
        private System.Windows.Forms.TextBox textMul;
        private System.Windows.Forms.Button butCalc1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textChaT;
        private System.Windows.Forms.TextBox textOpeT;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button butCalc2;
        private System.Windows.Forms.TextBox textChaF;
        private System.Windows.Forms.TextBox textChaN;
        private System.Windows.Forms.TextBox textOpeF;
        private System.Windows.Forms.TextBox textOpeN;
    }
}

