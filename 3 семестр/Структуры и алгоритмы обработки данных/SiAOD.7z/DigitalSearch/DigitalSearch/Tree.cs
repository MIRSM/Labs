﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalSearch
{
    //узел бора
    class Tree
    {
        //конструкторы
        public Tree() { }
        public Tree(char val)
        {
            this.Val = val;
        }

        //символ, который хранит узел
        private char val;
        public char Val { get => val; set => val = value; }

        //следующий узел на том же уровне
        private Tree right = null;
        internal Tree Right { get => right; set => right = value; }

        //узел на следующем уровне
        private Tree down = null;
        internal Tree Down { get => down; set => down = value; }


    }
}
