﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DigitalSearch
{
    //бор
    class DigitalSearchTree
    {
        public DigitalSearchTree() { }

        //первый узел дерева(корень)
        private Tree root = null;

        //возвращает узел который содержит val
        //если ни один узел не содержит val, возвращает null
        //принимает элемент на начало списка Tree, и символ val
        private Tree SearchRight(Tree Tree, char val)
        {
            while (Tree.Right != null && Tree.Right.Val != val)
                Tree = Tree.Right;
            return Tree;
        }

        //добавляет вправо узел с символом val, после Tree и возвращет новый узел
        private Tree AddCharRight(Tree Tree, char val)
        {
            Tree.Right = new Tree(val);
            return Tree.Right;
        }

        //добавляет вниз узел с символом val, после Tree и возвращет новый узел
        private Tree AddCharDown(Tree Tree, char val)
        {
            Tree.Down = new Tree(val);
            return Tree.Down;
        }
       
        //осуществляет поиск совпадающей части слова s, начиная с позиции i и узла Tree
        private bool SearchOfMatchingPart(string s, ref int i, ref Tree Tree)
        {
            while (i < s.Length)
            {
                if (Tree.Val != s[i])
                {
                    Tree = SearchRight(Tree, s[i]);
                    if (Tree.Right == null) return false;
                    Tree = Tree.Right;
                }
                if (Tree.Down != null)
                {
                    Tree = Tree.Down;
                }
                i++;
            }
            return true;
        }

        //добавляет слово в бор
        //возвращает удалось ли добавить слово в бор
        public bool AddWord(string s)
        {
            int i = 0;
            if (root == null) root = new Tree(s[i]);
            Tree Tree = root;

            //поиск совпадающей части
            if (SearchOfMatchingPart(s, ref i, ref Tree)) return false;
            
            //добавление первого несовпадающего символа вправо
            Tree = AddCharRight(Tree, s[i]);
            i++;

            //добавление оставшихся символов вниз
            while(i < s.Length)
            {
                Tree = AddCharDown(Tree, s[i]);
                i++;
            }

            return true;
            
        }

        //возвращает содержится ли слово s в боре
        public bool Contains(string s)
        {
            Tree Tree = root;
            int i = 0;
            return (root != null && SearchOfMatchingPart(s, ref i, ref Tree));
        }


    }
}
