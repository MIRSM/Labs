﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigitalSearch
{
    public partial class Form1 : Form
    {
        //бор
        private DigitalSearchTree digitalSearchTree = new DigitalSearchTree();

        //иницилизация
        public Form1()
        {
            InitializeComponent();
        }

        //обработчки кнопк "добавить"
        private void button1_Click(object sender, EventArgs e)
        {
            string word = textBox1.Text;
            if (word == "") {
                label1.ForeColor = Color.Red;
                label1.Text = "Пустое поле ввода";
                return;
            }
            word += '#';
            if (digitalSearchTree.AddWord(word))
            {
                richTextBox1.Text += textBox1.Text + "\n";
                label1.ForeColor = Color.Green;
                label1.Text = "Слово успешно добавлено";
            }
            else
            {
                label1.ForeColor = Color.Red;
                label1.Text = "Дублирование слова";
            }
        }

        //обработчик кнопки "найти"
        private void button2_Click(object sender, EventArgs e)
        {
            string word = textBox1.Text;
            if (word == "")
            {
                label1.ForeColor = Color.Red;
                label1.Text = "Пустое поле ввода";
                return;
            }
            word += '#';
            if (digitalSearchTree.Contains(word))
            {
                label1.ForeColor = Color.Green;
                label1.Text = "Слово найдено";
            }
            else
            {
                label1.ForeColor = Color.Red;
                label1.Text = "Слово не найдено";
            }
        }
    }
}
