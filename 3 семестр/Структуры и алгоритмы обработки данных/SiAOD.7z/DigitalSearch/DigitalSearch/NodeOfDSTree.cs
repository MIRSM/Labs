﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalSearch
{
    //узел бора
    class NodeOfDSTree
    {
        //конструкторы
        public NodeOfDSTree() { }
        public NodeOfDSTree(char val)
        {
            this.Val = val;
        }

        //символ, который хранит узел
        private char val;
        public char Val { get => val; set => val = value; }

        //следующий узел на том же уровне
        private NodeOfDSTree right = null;
        internal NodeOfDSTree Right { get => right; set => right = value; }

        //узел на следующем уровне
        private NodeOfDSTree down = null;
        internal NodeOfDSTree Down { get => down; set => down = value; }


    }
}
