﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace OOP5
{
    /// <summary>
    /// Родительский класс "Компания"
    /// </summary>
    abstract class Company
    {
        public String name_f;

        public abstract new string[] ToString();
    }

    /// <summary>
    /// Класс "Транспортная компания"
    /// </summary>
    class Transport : Company
    {
        public double pay_for_t;    //Оплата за тонну
        public int mas;             //Масса груза
        public char type_g;         //Класс груза (опасный/ценный/обычный)
        public int num_s;           //Количество грузчиков
        public int num_m;           //Количество машин для перевозки
        public String adr_from;     //Адрес перевозки
        public String adr_to;       //Адрес перевозки
        public static Stack<Transport> stackTr = new Stack<Transport>();

       
        /// <summary>
        /// Конструктор с параметрами
        /// </summary>
        /// <param name="n">Название</param>
        /// <param name="pay">Цена за 1 т.</param>
        /// <param name="m">Масса груза</param>
        /// <param name="tg">Класс груза</param>
        /// <param name="ns">Количество грузчиков</param>
        /// <param name="nc">Количество машин для перевозки</param>
        /// <param name="af">Пункт отправления</param>
        /// <param name="at">Пункт назначения</param>
        public Transport(String n, double pay, int m, char tg, int ns, int nc, String af, String at)
        {
            name_f = n;
            pay_for_t = pay;
            mas = m;
            type_g = tg;
            num_s = ns;
            num_m = nc;
            adr_from = af;
            adr_to = at;
        }

        /// <summary>
        /// Конструктор без параметров
        /// </summary>
        public Transport() : this("Неопределенно", 0, 0, 'N', 0, 0, "", "");

        /// <summary>
        /// Сравнение объектов
        /// </summary>
        /// <param name="obj">Передаваемый объъект</param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        /// <summary>
        /// Получение хэш-кода
        /// </summary>
        /// <returns>Хэш-код</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        /// <summary>
        /// Перегрузка оператора "!="
        /// </summary>
        /// <param name="tr1">Объект слева от оператора</param>
        /// <param name="tr2">Объект справа от оператора</param>
        /// <returns>Совпадают или нет</returns>
        public static bool operator !=(Transport tr1, Transport tr2)
        {
            return (tr1.mas != tr2.mas || tr1.pay_for_t != tr2.pay_for_t || tr1.type_g != tr2.type_g ||
                tr1.num_s != tr2.num_s || tr1.num_m != tr2.num_m) ? true : false;
            //  || tr1.name_f != tr2.name_f ||
            //    tr1.adr_from != tr2.adr_from || tr1.adr_to != tr2.adr_to
        }

        /// <summary>
        /// Перегрузка оператора "=="
        /// </summary>
        /// <param name="tr1">Объект слева от оператора</param>
        /// <param name="tr2">Объект справа от оператора</param>
        /// <returns>Совпадают или нет</returns>
        public static bool operator ==(Transport tr1, Transport tr2)
        {
            return (tr1.mas == tr2.mas && tr1.pay_for_t == tr2.pay_for_t && tr1.type_g == tr2.type_g &&
                tr1.num_s == tr2.num_s && tr1.num_m == tr2.num_m) ? true : false;

        }

        /// <summary>
        /// Добавление в коллекцию
        /// </summary>
        /// <param name="tr">Добавляемый объект</param>
        /// <returns>Добавляемый объект</returns>
        public static Transport operator ++(Transport tr)
        {
            stackTr.Push(tr);
            return tr;
        }

        /// <summary>
        /// Удаление из коллекции
        /// </summary>
        /// <param name="tr">Удаляемый  объект</param>
        /// <returns>Удаляемый объект</returns>
        public static Transport operator --(Transport tr)
        {
            stackTr.Pop();
            return tr;
        }

        /// <summary>
        /// Преобразование объекта в массив string
        /// </summary>
        /// <returns>Массив string со всеми полями объекта</returns>
        public override string[] ToString()
        {
            string[] row = new string[8];
            row[0] = name_f;
            row[1] = Convert.ToString(pay_for_t);
            row[2] = Convert.ToString(mas);
            row[3] = Convert.ToString(type_g);
            row[4] = Convert.ToString(num_s);
            row[5] = Convert.ToString(num_m);
            row[6] = adr_from;
            row[7] = adr_to;

            return row;
        }
    }

    /// <summary>
    /// Класс для задания
    /// </summary>
    class JustARandomClass : Company
    {
        public int[] randMass;      //массив чисел
        public string[] strMass;    //массив string

        public JustARandomClass()
        {
            Random r = new Random();
            randMass = new int[5];
            strMass = new string[5];

            for (int i = 0; i < 5; i++)
            {
                strMass[i] = 'a' + Convert.ToString(i);
                randMass[i] = r.Next(1, 100);
            }
        }

        /// <summary>
        /// Собирает массивы int и string в массив string
        /// </summary>
        /// <returns>Массив string</returns>
        public override string[] ToString()
        {
            string[] row = new string[10];
            for (int i = 0; i < 5; i++) row[i] = Convert.ToString(randMass[i]);
            for (int i = 5; i < 10; i++) row[i] = strMass[i - 5];

            return row;
        }
    }

    /// <summary>
    /// Форма
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// Инициализация формы
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

      
        /// <summary>
        /// Старт таймера
        /// </summary>
        /// <param name="sender">Объект кнопки</param>
        /// <param name="e">Событие нажатия</param>
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        int i = 0;
        /// <summary>
        /// Заполнение коллекции каждый тик
        /// </summary>
        /// <param name="sender">Объект таймера</param>
        /// <param name="e">Событие тика</param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;

            Random r = new Random();
            string[] row = new string[8];

            string name = "Название " + i;
            double pay = r.Next(10, 1000);
            int mas = r.Next(1, 500);
            char gType = ' ';
            switch (r.Next(1, 3))
            {
                case 1:
                    gType = 'D';
                    break;
                case 2:
                    gType = 'V';
                    break;
                case 3:
                    gType = 'N';
                    break;
            }
            int manC = r.Next(1, 10);
            int carC = r.Next(1, 10);
            string adrFrom = "Адрес " + i;
            string adrTo = "Адрес " + (20 + i);

            Transport tr = new Transport(name, pay, mas, gType,
                manC, carC, adrFrom, adrTo);

            row = tr.ToString();
            tr++;
            dataGridView1.Rows.Add(row);

        }

        /// <summary>
        /// Остановка таймера
        /// </summary>
        /// <param name="sender">Объект кнопки</param>
        /// <param name="e">Событие нажатия</param>
        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        int j = 0;
        /// <summary>
        /// Удаление крайнего элемента коллекции
        /// </summary>
        /// <param name="sender">Объект кнопки</param>
        /// <param name="e">Событие нажатия</param>
        private void button4_Click(object sender, EventArgs e)
        {

            if (j < i)
            {
                Transport tr = new Transport();
                string[] row = new string[8];

                row = Transport.stackTr.Peek().ToString();
                tr--;

                dataGridView2.Rows.Add(row);
                j++;
            }
            else MessageBox.Show("Коллекция пуста!");
        }

        /// <summary>
        /// Сравнение двух объектов
        /// </summary>
        /// <param name="sender">Объект кнопки</param>
        /// <param name="e">Событие нажатия</param>
        private void button3_Click(object sender, EventArgs e)
        {
            Transport tr1 = new Transport();
            Transport tr2 = new Transport();

            bool true1 = false;
            bool true2 = false;

            bool false1 = false;

            if (maskedTextBox1.Text == "" || maskedTextBox2.Text == "" || maskedTextBox3.Text == "" ||
                maskedTextBox4.Text == "" || maskedTextBox5.Text == "" || maskedTextBox6.Text == "" ||
                maskedTextBox7.Text == "" || maskedTextBox8.Text == "" || maskedTextBox9.Text == "" ||
                maskedTextBox10.Text == "" || maskedTextBox11.Text == "" || maskedTextBox12.Text == "" ||
                maskedTextBox13.Text == "" || maskedTextBox14.Text == "" || maskedTextBox15.Text == "" ||
                maskedTextBox16.Text == "") false1 = true;

            if (false1)
            {
                //Изменение цвета полей
                {
                    maskedTextBox1.BackColor = (maskedTextBox1.Text == "") ? Color.Red : Color.White;
                    maskedTextBox2.BackColor = (maskedTextBox2.Text == "") ? Color.Red : Color.White;
                    maskedTextBox3.BackColor = (maskedTextBox3.Text == "") ? Color.Red : Color.White;
                    maskedTextBox4.BackColor = (maskedTextBox4.Text == "") ? Color.Red : Color.White;
                    maskedTextBox5.BackColor = (maskedTextBox5.Text == "") ? Color.Red : Color.White;
                    maskedTextBox6.BackColor = (maskedTextBox6.Text == "") ? Color.Red : Color.White;
                    maskedTextBox7.BackColor = (maskedTextBox7.Text == "") ? Color.Red : Color.White;
                    maskedTextBox8.BackColor = (maskedTextBox8.Text == "") ? Color.Red : Color.White;
                    maskedTextBox9.BackColor = (maskedTextBox9.Text == "") ? Color.Red : Color.White;
                    maskedTextBox10.BackColor = (maskedTextBox10.Text == "") ? Color.Red : Color.White;
                    maskedTextBox11.BackColor = (maskedTextBox11.Text == "") ? Color.Red : Color.White;
                    maskedTextBox12.BackColor = (maskedTextBox12.Text == "") ? Color.Red : Color.White;
                    maskedTextBox13.BackColor = (maskedTextBox13.Text == "") ? Color.Red : Color.White;
                    maskedTextBox14.BackColor = (maskedTextBox14.Text == "") ? Color.Red : Color.White;
                    maskedTextBox15.BackColor = (maskedTextBox15.Text == "") ? Color.Red : Color.White;
                    maskedTextBox16.BackColor = (maskedTextBox16.Text == "") ? Color.Red : Color.White;
                }
                MessageBox.Show("Заполните все поля!");
            }
            else
            {
                //Изменение цвета полей
                {
                    maskedTextBox1.BackColor = Color.White;
                    maskedTextBox2.BackColor = Color.White;
                    maskedTextBox3.BackColor = Color.White;
                    maskedTextBox4.BackColor = Color.White;
                    maskedTextBox5.BackColor = Color.White;
                    maskedTextBox6.BackColor = Color.White;
                    maskedTextBox7.BackColor = Color.White;
                    maskedTextBox8.BackColor = Color.White;
                    maskedTextBox9.BackColor = Color.White;
                    maskedTextBox10.BackColor = Color.White;
                    maskedTextBox11.BackColor = Color.White;
                    maskedTextBox12.BackColor = Color.White;
                    maskedTextBox13.BackColor = Color.White;
                    maskedTextBox14.BackColor = Color.White;
                    maskedTextBox15.BackColor = Color.White;
                    maskedTextBox16.BackColor = Color.White;
                }

                //Заполнение первого объекта
                if (Convert.ToChar(maskedTextBox4.Text.ToUpper()) == 'D' ||
                    Convert.ToChar(maskedTextBox4.Text.ToUpper()) == 'V' ||
                    Convert.ToChar(maskedTextBox4.Text.ToUpper()) == 'N')
                {
                    tr1.name_f = maskedTextBox1.Text;
                    tr1.pay_for_t = Convert.ToDouble(maskedTextBox2.Text);
                    tr1.mas = Convert.ToInt32(maskedTextBox3.Text);
                    tr1.type_g = Convert.ToChar(maskedTextBox4.Text.ToUpper());
                    tr1.num_s = Convert.ToInt32(maskedTextBox5.Text);
                    tr1.num_m = Convert.ToInt32(maskedTextBox6.Text);
                    tr1.adr_from = maskedTextBox7.Text;
                    tr1.adr_to = maskedTextBox8.Text;

                    true1 = true;
                }
                else
                {
                    maskedTextBox4.BackColor = Color.Red;
                    MessageBox.Show("Неверный класс груза в первом объекте! (Требуется 'D', 'V' или 'N')");
                }

                //Заполнение второго объекта
                if (Convert.ToChar(maskedTextBox13.Text.ToUpper()) == 'D' ||
                    Convert.ToChar(maskedTextBox13.Text.ToUpper()) == 'V' ||
                    Convert.ToChar(maskedTextBox13.Text.ToUpper()) == 'N')
                {

                    tr2.name_f = maskedTextBox16.Text;
                    tr2.pay_for_t = Convert.ToDouble(maskedTextBox15.Text);
                    tr2.mas = Convert.ToInt32(maskedTextBox14.Text);
                    tr2.type_g = Convert.ToChar(maskedTextBox13.Text.ToUpper());
                    tr2.num_s = Convert.ToInt32(maskedTextBox12.Text);
                    tr2.num_m = Convert.ToInt32(maskedTextBox11.Text);
                    tr2.adr_from = maskedTextBox10.Text;
                    tr2.adr_to = maskedTextBox9.Text;

                    true2 = true;
                }
                else
                {
                    maskedTextBox13.BackColor = Color.Red;
                    MessageBox.Show("Неверный класс груза во втором объекте! (Требуется 'D', 'V' или 'N')");
                }

                //Вывод результата сравнения
                if (true1 && true2) MessageBox.Show(tr1 == tr2 ? "Объекты идентичны!" : "Объекты различаются!");
            }
        }

        /// <summary>
        /// Работа двух функций с одинаковым названием в разных классах
        /// </summary>
        /// <param name="sender">Объект кнопки</param>
        /// <param name="e">Событие нажатия</param>
        private void button5_Click(object sender, EventArgs e)
        {
            dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            {
                Random r = new Random();
                string[] row = new string[8];

                string name = "Название ";
                double pay = r.Next(10, 1000);
                int mas = r.Next(1, 500);
                char gType = ' ';
                switch (r.Next(1, 3))
                {
                    case 1:
                        gType = 'D';
                        break;
                    case 2:
                        gType = 'V';
                        break;
                    case 3:
                        gType = 'N';
                        break;
                }
                int manC = r.Next(1, 10);
                int carC = r.Next(1, 10);
                string adrFrom = "Адрес ";
                string adrTo = "Адрес " + 20;

                Transport tr = new Transport(name, pay, mas, gType,
                    manC, carC, adrFrom, adrTo);

                row = tr.ToString();

                dataGridView3.Rows.Add(row);
                dataGridView3.Rows[0].HeaderCell.Value = "Transport";
            }
            {
                JustARandomClass jrc = new JustARandomClass();
                string[] row = new string[10];

                row = jrc.ToString();

                dataGridView3.Rows.Add(row);
                dataGridView3.Rows[1].HeaderCell.Value = "JRC";
            }
        }
    }
}
