﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace OOP8
{
    public partial class Form2 : Form
    {
        public Form2(List<Form1.Transport> t)
        {
            InitializeComponent();
            dataGridView1.Rows.Clear();
            foreach(var tr in t)
            {
                string[] row = tr.ToString();
                dataGridView1.Rows.Add(row);
            }
        }
        

        private void BackButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
