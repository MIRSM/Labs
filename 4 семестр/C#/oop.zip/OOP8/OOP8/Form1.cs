﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;
using System.Linq;

namespace OOP8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            for (int i = 0; i < 10; i++) transports[i] = new List<Transport>();
            button2.Enabled = false;
            button3.Enabled = false;
            saveMenu.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
        }

        List<Transport>[] transports = new List<Transport>[10];

        private void button1_Click(object sender, EventArgs e)
        {
            Transport tr1 = new Transport();

            bool false1 = false;

            if (textBox1.Text == "" || maskedTextBox1.Text == "" || maskedTextBox2.Text == "" || maskedTextBox3.Text == "" ||
                maskedTextBox4.Text == "" || maskedTextBox5.Text == "" || textBox2.Text == "" ||
                textBox3.Text == "") false1 = true;

            if (false1)
            {
                //Изменение цвета полей
                {
                    maskedTextBox1.BackColor = (maskedTextBox1.Text == "") ? Color.Red : Color.White;
                    maskedTextBox2.BackColor = (maskedTextBox2.Text == "") ? Color.Red : Color.White;
                    maskedTextBox3.BackColor = (maskedTextBox3.Text == "") ? Color.Red : Color.White;
                    maskedTextBox4.BackColor = (maskedTextBox4.Text == "") ? Color.Red : Color.White;
                    maskedTextBox5.BackColor = (maskedTextBox5.Text == "") ? Color.Red : Color.White;
                    textBox1.BackColor = (textBox1.Text == "") ? Color.Red : Color.White;
                    textBox2.BackColor = (textBox2.Text == "") ? Color.Red : Color.White;
                    textBox3.BackColor = (textBox3.Text == "") ? Color.Red : Color.White;
                }
                MessageBox.Show("Заполните все поля!");
            }
            else
            {
                //Изменение цвета полей
                {
                    maskedTextBox1.BackColor = Color.White;
                    maskedTextBox2.BackColor = Color.White;
                    maskedTextBox3.BackColor = Color.White;
                    maskedTextBox4.BackColor = Color.White;
                    maskedTextBox5.BackColor = Color.White;
                    textBox1.BackColor = Color.White;
                    textBox2.BackColor = Color.White;
                    textBox3.BackColor = Color.White;
                }

                //Заполнение объекта
                if (Convert.ToChar(maskedTextBox3.Text.ToUpper()) == 'D' ||
                    Convert.ToChar(maskedTextBox3.Text.ToUpper()) == 'V' ||
                    Convert.ToChar(maskedTextBox3.Text.ToUpper()) == 'N')
                {

                    tr1.name_f = textBox1.Text;
                    tr1.pay_for_t = Convert.ToDouble(maskedTextBox1.Text);
                    tr1.mas = Convert.ToInt32(maskedTextBox2.Text);
                    tr1.type_g = Convert.ToChar(maskedTextBox3.Text.ToUpper());
                    tr1.num_m = Convert.ToInt32(maskedTextBox4.Text);
                    tr1.num_s = Convert.ToInt32(maskedTextBox5.Text);
                    tr1.adr_from = textBox2.Text;
                    tr1.adr_to = textBox3.Text;

                    string[] row = new string[8];

                    Random r = new Random();
                    transports[r.Next(0, 10)].Add(tr1);
                    //transports[9].Add(tr1);
                    row = tr1.ToString();

                    dataGridView1.Rows.Add(row);
                    ClearBoxes();

                    if (!button2.Enabled)
                    {
                        button2.Enabled = true;
                        button3.Enabled = true;
                        button4.Enabled = true;
                        button5.Enabled = true;
                        saveMenu.Enabled = true;
                    }
                }
                else
                {
                    maskedTextBox3.BackColor = Color.Red;
                    MessageBox.Show("Неверный класс груза в первом объекте! (Требуется 'D', 'V' или 'N')");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            for (int i = 0; i < 10; i++)
            {
                if (transports[i].Count > 0)
                {
                    string[] spliter = { $"Список №{i}", "----", "----", "----", "----", "----", "----", "----" };
                    dataGridView1.Rows.Add(spliter);

                    List<Transport> transportsList = new List<Transport>();
                    transportsList = transports[i].ToList();
                    if (radioButton1.Checked)
                    {
                        transportsList.Sort();
                    }
                    else
                    {
                        transportsList.Sort(new TransportComparer());
                    }
                    foreach (Transport t in transportsList)
                    {
                        string[] row = t.ToString();
                        dataGridView1.Rows.Add(row);
                    }
                }
                else
                {
                    string[] spliter = { $"Список №{i} ", "пуст", "пуст", "пуст", "пуст", "пуст", "пуст", "пуст" };
                    dataGridView1.Rows.Add(spliter);
                }
            }



        }

        private void saveMenu_Click(object sender, EventArgs e)
        {
            BinaryFormatter formater = new BinaryFormatter();
            using (FileStream fs = new FileStream("Transports.dat", FileMode.OpenOrCreate))
            {
                formater.Serialize(fs, transports);
            }

        }

        private void loadMenu_Click(object sender, EventArgs e)
        {
            if (!button2.Enabled)
            {
                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = true;
                button5.Enabled = true;
                saveMenu.Enabled = true;
            }

            BinaryFormatter formatter = new BinaryFormatter();
            using (FileStream fs = new FileStream("Transports.dat", FileMode.OpenOrCreate))
            {
                transports = (List<Transport>[])formatter.Deserialize(fs);
            }
            dataGridView1.Rows.Clear();
            for (int i = 0; i < 10; i++)
            {
                if (transports[i].Count > 0)
                {
                    foreach(Transport t in transports[i])
                    {
                        string[] row = t.ToString();
                        dataGridView1.Rows.Add(row);
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var maxN = transports.Max(t => t.Count);
            var minN = transports.Min(t => t.Count);

            MessageBox.Show($"Максимальный/минимальный размер коллекции:{maxN}/{minN}");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(numericUpDown1.Value);

            var selectetList = from t in transports where t.Count == n select t;
            if (selectetList.Count() != 0)
                foreach (var t in selectetList)
                {
                    MessageBox.Show($"Коллекция с заданной размерностью выведена в таблицу!");

                    Form2 form2 = new Form2(t);
                    form2.ShowDialog();

                }
            else MessageBox.Show("Коллекций с заданной размерностью нет!");
            
        }

        [Serializable]
        public class Transport : IComparable<Transport>
        {
            public string name_f;       //Название фирмы
            public double pay_for_t;    //Оплата за тонну
            public int mas;             //Масса груза
            public char type_g;         //Класс груза (опасный/ценный/обычный)
            public int num_s;           //Количество грузчиков
            public int num_m;           //Количество машин для перевозки
            public String adr_from;     //Адрес перевозки
            public String adr_to;       //Адрес перевозки

            /// <summary>
            /// Конструктор с параметрами
            /// </summary>
            /// <param name="n">Название</param>
            /// <param name="pay">Цена за 1 т.</param>
            /// <param name="m">Масса груза</param>
            /// <param name="tg">Класс груза</param>
            /// <param name="ns">Количество грузчиков</param>
            /// <param name="nc">Количество машин для перевозки</param>
            /// <param name="af">Пункт отправления</param>
            /// <param name="at">Пункт назначения</param>
            public Transport(String n, double pay, int m, char tg, int ns, int nc, String af, String at)
            {
                name_f = n;
                pay_for_t = pay;
                mas = m;
                type_g = tg;
                num_s = ns;
                num_m = nc;
                adr_from = af;
                adr_to = at;
            }

            /// <summary>
            /// Конструктор без параметров
            /// </summary>
            public Transport()
            {
                name_f = "Неопределенно";
                pay_for_t = 0;
                mas = 0;
                type_g = 'N';
                num_s = 0;
                num_m = 0;
                adr_from = "";
                adr_to = "";
            }

            /// <summary>
            /// Деструктор
            /// </summary>
            ~Transport()
            {
                //Console.Beep();
            }

            /// <summary>
            /// Преобразование объекта в массив string
            /// </summary>
            /// <returns>Массив string со всеми полями объекта</returns>
            public new string[] ToString()
            {
                string[] row = new string[8];
                row[0] = name_f;
                row[1] = Convert.ToString(pay_for_t);
                row[2] = Convert.ToString(mas);
                row[3] = Convert.ToString(type_g);
                row[4] = Convert.ToString(num_m);
                row[5] = Convert.ToString(num_s);
                row[6] = adr_from;
                row[7] = adr_to;

                return row;
            }

            /// <summary>
            /// Реализация интерфейса IComparable<Transport>
            /// </summary>
            /// <param name="obj">Объект сравнения</param>
            /// <returns></returns>
            public int CompareTo(Transport obj)
            {
                if (this.pay_for_t > obj.pay_for_t)
                    return 1;
                if (this.pay_for_t < obj.pay_for_t)
                    return -1;
                else
                    return 0;
            }
        }

        /// <summary>
        /// Компаратор для сортировки по убыванию
        /// </summary>
        class TransportComparer : IComparer<Transport>
        {
            public int Compare(Transport t1, Transport t2)
            {
                if (t1.pay_for_t > t2.pay_for_t)
                    return -1;
                if (t1.pay_for_t < t2.pay_for_t)
                    return 1;
                else
                    return 0;
            }
        }

        /// <summary>
        /// Очистка полей ввода
        /// </summary>
        public void ClearBoxes()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            maskedTextBox1.Text = "";
            maskedTextBox2.Text = "";
            maskedTextBox3.Text = "";
            maskedTextBox4.Text = "";
            maskedTextBox5.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            switch (comboBox1.Text)
            {
                case "Минимальная цена в первой коллекции":
                    try
                    {
                        var minInF = transports.FirstOrDefault().Min(t => t.pay_for_t);
                        MessageBox.Show($"Минимальная цена в первой коллекции: {minInF}");
                    }
                    catch (InvalidOperationException)
                    {
                        MessageBox.Show("Первая коллекция пуста!");
                    }
                    break;
                case "Максимальная цена в последней коллекции, где тип груза - N":
                    try
                    {
                        var maxInF = transports.LastOrDefault().Where(t=>t.type_g=='N').Max(t => t.pay_for_t);
                        MessageBox.Show($"Максимальная цена в последней коллекции, где тип груза - N: {maxInF}");
                    }
                    catch (InvalidOperationException)
                    {
                        MessageBox.Show("Таких элементов коллекции нет!");
                    }
                    break;
                case "Суммарная масса груза в последней коллекции, где количество грузчиков больше 10":
                    var summ = transports.Last().Where(t=>t.num_s>10).Sum(t => t.mas);
                    if (summ != 0)
                        MessageBox.Show($"Суммарная масса: {summ}");
                    else MessageBox.Show("В коллекци элементов нет!");
                    break;
                case "Компаний с ценой больше 1000":
                    int c = 0;
                    foreach (var t in transports)
                    {
                        c += t.Where(item => item.pay_for_t > 1000).Count();
                    }
                    MessageBox.Show($"Компаний с ценой большей 1000: {c}");
                    break;
                default:
                    MessageBox.Show("Выберите один из вариантов!");
                    break;
            }

        }
    }
}
