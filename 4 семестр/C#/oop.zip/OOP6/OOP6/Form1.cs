﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace OOP6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            tabControl1.Enabled = false;
            tabControl1.Visible = false;
        }

        [DllImport("user32.dll")]
        public static extern int MessageBox(int hWnd, string text, string caption, uint type);

        //Кнопка "Сохранить"
        private void button1_Click(object sender, EventArgs e)
        {
            Transport tr1 = new Transport();

            bool false1 = false;

            if (textBox1.Text == "" || maskedTextBox1.Text == "" || maskedTextBox2.Text == "" ||
                maskedTextBox3.Text == "" || maskedTextBox4.Text == "" || maskedTextBox5.Text == "" ||
                textBox2.Text == "" || textBox3.Text == "") false1 = true;

            if (false1)
            {
                //Изменение цвета полей
                {
                    textBox1.BackColor = (textBox1.Text == "") ? Color.Red : Color.White;
                    textBox2.BackColor = (textBox2.Text == "") ? Color.Red : Color.White;
                    textBox3.BackColor = (textBox3.Text == "") ? Color.Red : Color.White;
                    maskedTextBox1.BackColor = (maskedTextBox1.Text == "") ? Color.Red : Color.White;
                    maskedTextBox2.BackColor = (maskedTextBox2.Text == "") ? Color.Red : Color.White;
                    maskedTextBox3.BackColor = (maskedTextBox3.Text == "") ? Color.Red : Color.White;
                    maskedTextBox4.BackColor = (maskedTextBox4.Text == "") ? Color.Red : Color.White;
                    maskedTextBox5.BackColor = (maskedTextBox5.Text == "") ? Color.Red : Color.White;

                }
                MessageBox(0,"Заполните все поля!", "Сообщение", 0);
            }
            else
            {
                //Изменение цвета полей
                {
                    textBox1.BackColor = Color.White;
                    textBox2.BackColor = Color.White;
                    textBox3.BackColor = Color.White;
                    maskedTextBox1.BackColor = Color.White;
                    maskedTextBox2.BackColor = Color.White;
                    maskedTextBox3.BackColor = Color.White;
                    maskedTextBox4.BackColor = Color.White;
                    maskedTextBox5.BackColor = Color.White;

                }

                //Заполнение первого объекта
                if (Convert.ToChar(maskedTextBox3.Text.ToUpper()) == 'D' ||
                    Convert.ToChar(maskedTextBox3.Text.ToUpper()) == 'V' ||
                    Convert.ToChar(maskedTextBox3.Text.ToUpper()) == 'N')
                {
                    tr1.name_f = textBox1.Text;
                    tr1.pay_for_t = Convert.ToDouble(maskedTextBox1.Text);
                    tr1.mas = Convert.ToInt32(maskedTextBox2.Text);
                    tr1.type_g = Convert.ToChar(maskedTextBox3.Text.ToUpper());
                    tr1.num_s = Convert.ToInt32(maskedTextBox4.Text);
                    tr1.num_m = Convert.ToInt32(maskedTextBox5.Text);
                    tr1.adr_from = textBox2.Text;
                    tr1.adr_to = textBox3.Text;

                    string[] row = new string[8];
                    row[0] = tr1.name_f;
                    row[1] = Convert.ToString(tr1.pay_for_t);
                    row[2] = Convert.ToString(tr1.mas);
                    row[3] = Convert.ToString(tr1.type_g);
                    row[4] = Convert.ToString(tr1.num_s);
                    row[5] = Convert.ToString(tr1.num_m);
                    row[6] = tr1.adr_from;
                    row[7] = tr1.adr_to;

                    dataGridView1.Rows.Add(row);

                    MessageBox(0,"Данные сохранены!", "Сообщение", 0);
                }
                else
                {
                    maskedTextBox3.BackColor = Color.Red;
                    MessageBox(0,"Неверный класс груза в первом объекте! (Требуется 'D', 'V' или 'N')", "Сообщение", 0);
                }
            }

        }

        //Кнопка "Исключение"
        private void button2_Click(object sender, EventArgs e)
        {
            string[] mass = new string[5];
            Object[] obMass = (Object[])mass;

            Transport tr1 = new Transport();
            bool false1 = false;

            if (textBox1.Text == "" || maskedTextBox1.Text == "" || maskedTextBox2.Text == "" ||
                maskedTextBox3.Text == "" || maskedTextBox4.Text == "" || maskedTextBox5.Text == "" ||
                textBox2.Text == "" || textBox3.Text == "") false1 = true;

            if (false1)
            {
                //Изменение цвета полей
                {
                    textBox1.BackColor = (textBox1.Text == "") ? Color.Red : Color.White;
                    textBox2.BackColor = (textBox2.Text == "") ? Color.Red : Color.White;
                    textBox3.BackColor = (textBox3.Text == "") ? Color.Red : Color.White;
                    maskedTextBox1.BackColor = (maskedTextBox1.Text == "") ? Color.Red : Color.White;
                    maskedTextBox2.BackColor = (maskedTextBox2.Text == "") ? Color.Red : Color.White;
                    maskedTextBox3.BackColor = (maskedTextBox3.Text == "") ? Color.Red : Color.White;
                    maskedTextBox4.BackColor = (maskedTextBox4.Text == "") ? Color.Red : Color.White;
                    maskedTextBox5.BackColor = (maskedTextBox5.Text == "") ? Color.Red : Color.White;

                }
                MessageBox(0,"Заполните все поля!","Сообщение",0);
            }
            else
            {
                //Изменение цвета полей
                {
                    textBox1.BackColor = Color.White;
                    textBox2.BackColor = Color.White;
                    textBox3.BackColor = Color.White;
                    maskedTextBox1.BackColor = Color.White;
                    maskedTextBox2.BackColor = Color.White;
                    maskedTextBox3.BackColor = Color.White;
                    maskedTextBox4.BackColor = Color.White;
                    maskedTextBox5.BackColor = Color.White;
                }

                //Заполнение  объекта
                if (Convert.ToChar(maskedTextBox3.Text.ToUpper()) == 'D' ||
                    Convert.ToChar(maskedTextBox3.Text.ToUpper()) == 'V' ||
                    Convert.ToChar(maskedTextBox3.Text.ToUpper()) == 'N')
                {
                    tr1.name_f = textBox1.Text;
                    try
                    {
                        Object ob = (Object)(maskedTextBox1.Text);
                        obMass[0] = ob;
                        throw new MyException("Произведена попытка добавления object переменной в массив string!");

                    }
                    catch (MyException me)
                    {
                        
                        {
                            MessageBox(0,"Сгенерированно исключение: " + me.Message,"Сообщение",0);
                        }
                        
                    }
                    finally
                    {
                        obMass[0] =maskedTextBox1.Text;
                        tr1.pay_for_t = Convert.ToDouble(maskedTextBox1.Text);
                        MessageBox(0,"Было обработано значение поля 'Цена за тонну': "+Convert.ToString(obMass[0]), "Сообщение", 0);
                    }

                    tr1.mas = Convert.ToInt32(maskedTextBox2.Text);
                    tr1.type_g = Convert.ToChar(maskedTextBox3.Text.ToUpper());
                    tr1.num_s = Convert.ToInt32(maskedTextBox4.Text);
                    tr1.num_m = Convert.ToInt32(maskedTextBox5.Text);
                    tr1.adr_from = textBox2.Text;
                    tr1.adr_to = textBox3.Text;

                    string[] row = new string[8];
                    row[0] = tr1.name_f;
                    row[1] = Convert.ToString(tr1.pay_for_t);
                    row[2] = Convert.ToString(tr1.mas);
                    row[3] = Convert.ToString(tr1.type_g);
                    row[4] = Convert.ToString(tr1.num_s);
                    row[5] = Convert.ToString(tr1.num_m);
                    row[6] = tr1.adr_from;
                    row[7] = tr1.adr_to;

                    dataGridView1.Rows.Add(row);

                    MessageBox(0,"Данные сохранены!", "Сообщение", 0);
                }
                else
                {
                    maskedTextBox3.BackColor = Color.Red;
                    MessageBox(0,"Неверный класс груза в первом объекте! (Требуется 'D', 'V' или 'N')", "Сообщение", 0);
                }
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox(0,$"Здравствуйте, {textBox4.Text}! Тема данной лабораторной работы - Обработка исключительных ситуаций.\nВ рамках данной лабораторной работы мы будем обрабатывать исключительные ситуации!", "Сообщение", 0);
            textBox4.Enabled = false;
            textBox4.Visible = false;
            button3.Enabled = false;
            button3.Visible = false;
            label9.Visible = false;
            label9.Enabled = false;
            ActiveForm.Width=592;
            ActiveForm.Height = 440;
            tabControl1.Visible = true;
            tabControl1.Enabled = true;
            
        }
    }

    

    //Класс задания
    class Transport
    {
        public string name_f;        //Название фирмы
        public double pay_for_t;    //Оплата за тонну
        public int mas;             //Масса груза
        public char type_g;         //Класс груза (опасный/ценный/обычный)
        public int num_s;           //Количество грузчиков
        public int num_m;           //Количество машин для перевозки
        public String adr_from;     //Адрес перевозки
        public String adr_to;       //Адрес перевозки

        /// <summary>
        /// Конструктор без параметров
        /// </summary>
        public Transport()
        {
            name_f = "Неопределенно";
            pay_for_t = 0;
            mas = 0;
            type_g = 'N';
            num_s = 0;
            num_m = 0;
            adr_from = "";
            adr_to = "";
        }

        /// <summary>
        /// Конструктор с параметрами
        /// </summary>
        /// <param name="n">Название</param>
        /// <param name="pay">Цена за 1 т.</param>
        /// <param name="m">Масса груза</param>
        /// <param name="tg">Класс груза</param>
        /// <param name="ns">Количество грузчиков</param>
        /// <param name="nc">Количество машин для перевозки</param>
        /// <param name="af">Пункт отправления</param>
        /// <param name="at">Пункт назначения</param>
        public Transport(String n, double pay, int m, char tg, int ns, int nc, String af, String at)
        {
            name_f = n;
            pay_for_t = pay;
            mas = m;
            type_g = tg;
            num_s = ns;
            num_m = nc;
            adr_from = af;
            adr_to = at;
        }

        /// <summary>
        /// Преобразование объекта в массив string
        /// </summary>
        /// <returns>Массив string со всеми полями объекта</returns>
        public new string[] ToString()
        {
            string[] row = new string[8];
            row[0] = name_f;
            row[1] = Convert.ToString(pay_for_t);
            row[2] = Convert.ToString(mas);
            row[3] = Convert.ToString(type_g);
            row[4] = Convert.ToString(num_s);
            row[5] = Convert.ToString(num_m);
            row[6] = adr_from;
            row[7] = adr_to;

            return row;
        }
    }

    //Класс исключения
    class MyException : Exception
    {
        public MyException(string message) : base(message) { }
    }


}
