﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace OOP7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            tabControl1.Visible = false;
            tabControl1.Enabled = false;
        }

        int coun = -1;

        delegate int LengthName(string n);

        /// <summary>
        /// Нажатие кнопки "Сохранить"
        /// </summary>
        /// <param name="sender">Объект кнопки</param>
        /// <param name="e">Событие</param>
        private void button1_Click(object sender, EventArgs e)
        {
            Transport tr1 = new Transport();

            bool false1 = false;

            if (textBox1.Text == "" || maskedTextBox1.Text == "" || maskedTextBox2.Text == "" || maskedTextBox3.Text == "" ||
                maskedTextBox4.Text == "" || maskedTextBox5.Text == "" || textBox2.Text == "" ||
                textBox3.Text == "") false1 = true;

            if (false1)
            {
                //Изменение цвета полей
                {
                    maskedTextBox1.BackColor = (maskedTextBox1.Text == "") ? Color.Red : Color.White;
                    maskedTextBox2.BackColor = (maskedTextBox2.Text == "") ? Color.Red : Color.White;
                    maskedTextBox3.BackColor = (maskedTextBox3.Text == "") ? Color.Red : Color.White;
                    maskedTextBox4.BackColor = (maskedTextBox4.Text == "") ? Color.Red : Color.White;
                    maskedTextBox5.BackColor = (maskedTextBox5.Text == "") ? Color.Red : Color.White;
                    textBox1.BackColor = (textBox1.Text == "") ? Color.Red : Color.White;
                    textBox2.BackColor = (textBox2.Text == "") ? Color.Red : Color.White;
                    textBox3.BackColor = (textBox3.Text == "") ? Color.Red : Color.White;
                }
                MessageBox.Show("Заполните все поля!");
            }
            else
            {
                //Изменение цвета полей
                {
                    maskedTextBox1.BackColor = Color.White;
                    maskedTextBox2.BackColor = Color.White;
                    maskedTextBox3.BackColor = Color.White;
                    maskedTextBox4.BackColor = Color.White;
                    maskedTextBox5.BackColor = Color.White;
                    textBox1.BackColor = Color.White;
                    textBox2.BackColor = Color.White;
                    textBox3.BackColor = Color.White;
                }

                //Заполнение объекта
                if (Convert.ToChar(maskedTextBox4.Text.ToUpper()) == 'D' ||
                    Convert.ToChar(maskedTextBox4.Text.ToUpper()) == 'V' ||
                    Convert.ToChar(maskedTextBox4.Text.ToUpper()) == 'N')
                {
                    LengthName lengthName = n => n.Length;  //Делегат с использованием лямбда выражений (вычисляет длину передаваемой строки)

                    if (lengthName(textBox1.Text) > 15)
                    {
                        MessageBox.Show("Название фирмы слишком большое!");
                    }
                    else
                    {
                        tr1.name_f = textBox1.Text;
                        tr1.pay_for_t = Convert.ToDouble(maskedTextBox1.Text);
                        tr1.mas = Convert.ToInt32(maskedTextBox2.Text);
                        tr1.type_g = Convert.ToChar(maskedTextBox4.Text.ToUpper());
                        tr1.num_s = Convert.ToInt32(maskedTextBox3.Text);
                        tr1.num_m = Convert.ToInt32(maskedTextBox5.Text);
                        tr1.adr_from = textBox2.Text;
                        tr1.adr_to = textBox3.Text;

                        string[] row = new string[8];

                        row = tr1.ToString();

                        tr1.Added += ShowMess;  //tr1.Added += new Transport.CompanyStateHandler(ShowMess); - эквивалентны
                        tr1.AddToCol();

                        coun++;

                        dataGridView1.Rows.Add(row);
                    }
                }
                else
                {
                    maskedTextBox4.BackColor = Color.Red;
                    MessageBox.Show("Неверный класс груза в первом объекте! (Требуется 'D', 'V' или 'N')");
                }
            }
        }

        /// <summary>
        /// Вывод сообщения
        /// </summary>
        /// <param name="message">Сообщение</param>
        private static void ShowMess(object sender, CompanyEventArgs e)
        {
            MessageBox.Show(e.Message);
        }

        /// <summary>
        /// Сохранение всех элементов таблицы, кроме последнего
        /// </summary>
        /// <param name="row">Массив, куда будут сохраняться строки</param>
        /// <param name="coun">Количество сохраняемых строк (нумерация идет от 0 и не включая границу)</param>
        /// <param name="dgv">Таблица, из которой сохраняются значения</param>
         private void SaveRows(ref string[,] row,int coun,DataGridView dgv)
        {
            for (int j = 0; j < coun; j++)
            {
                for (int i = 0; i < 8; i++)
                {
                    row[j, i] = dgv[i, j].Value.ToString();
                }
            }
           
        }

        /// <summary>
        /// Вывод сохраненных строк
        /// </summary>
        /// <param name="row">Массив сохраненных строк</param>
        /// <param name="coun">Кол-во выведенных строк (нумерация идет от 0, не включая последний элемент)</param>
        /// <param name="dgv">Таблица, в которую сохраянются значения</param>
        private void ShowRows(string[,] row,ref int coun,ref DataGridView dgv)
        {
            dgv.Rows.Clear();
            for (int j = 0; j < coun; j++)
            {
                dataGridView1.Rows.Add();
                for (int i = 0; i < 8; i++)
                {
                    dgv[i, j].Value = row[j, i];
                }
            }

            Transport tr = new Transport();

            tr.Deleted += ShowMess;
            tr.DeletFromCol();

            coun--;
        }

        /// <summary>
        /// Нажатие кнопки "Удалить"
        /// </summary>
        /// <param name="sender">Объект кнопки</param>
        /// <param name="e">Событие</param>
        private void button2_Click(object sender, EventArgs e)
        {
            if (coun >= 0)
            {
               
                string[,] row = new string[coun,8];

                SaveRows(ref row,coun,dataGridView1);

                ShowRows(row, ref coun, ref dataGridView1);
            }
            else MessageBox.Show("Коллекция пуста!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Здравствуйте, {textBox4.Text}! Тема данной лабораторной работы - Делегаты и события.\nВ рамках данной лабораторной работы мы будем использовать делегаты и события!");
            label9.Enabled = false;
            label9.Visible = false;
            textBox4.Enabled = false;
            textBox4.Visible = false;
            button3.Enabled = false;
            button3.Visible = false;
            tabControl1.Enabled = true;
            tabControl1.Visible = true;
            ActiveForm.Width = 805;
            ActiveForm.Height = 344;
        }
    }

    /// <summary>
    /// Класс события
    /// </summary>
    class CompanyEventArgs
    {
        //Сообщение 
        public string Message { get; }

        public CompanyEventArgs(string mes)
        {
            Message = mes;
        }

    }

    /// <summary>
    /// Класс "Транспортная компания"
    /// </summary>
    class Transport
    {
        public string name_f;       //Название фирмы
        public double pay_for_t;    //Оплата за тонну
        public int mas;             //Масса груза
        public char type_g;         //Класс груза (опасный/ценный/обычный)
        public int num_s;           //Количество грузчиков
        public int num_m;           //Количество машин для перевозки
        public String adr_from;     //Адрес перевозки
        public String adr_to;       //Адрес перевозки
        public static Stack<Transport> stackTr = new Stack<Transport>();

        /// <summary>
        /// Делегат
        /// </summary>
        /// <param name="sender">Передаваемый объект</param>
        /// <param name="e">Событие</param>
        public delegate void CompanyStateHandler(object sender, CompanyEventArgs e);

        /// <summary>
        /// Событие, возникающее при добавлении элемента в коллекцию
        /// </summary>
        public event CompanyStateHandler Added;
        
        /// <summary>
        /// Событие, возникающее при удалении эелемента из коллекции
        /// </summary>
        public event CompanyStateHandler Deleted;

        /// <summary>
        /// Конструктор с параметрами
        /// </summary>
        /// <param name="n">Название</param>
        /// <param name="pay">Цена за 1 т.</param>
        /// <param name="m">Масса груза</param>
        /// <param name="tg">Класс груза</param>
        /// <param name="ns">Количество грузчиков</param>
        /// <param name="nc">Количество машин для перевозки</param>
        /// <param name="af">Пункт отправления</param>
        /// <param name="at">Пункт назначения</param>
        public Transport(String n, double pay, int m, char tg, int ns, int nc, String af, String at)
        {
            name_f = n;
            pay_for_t = pay;
            mas = m;
            type_g = tg;
            num_s = ns;
            num_m = nc;
            adr_from = af;
            adr_to = at;
        }

        /// <summary>
        /// Конструктор без параметров
        /// </summary>
        public Transport()
        {
            name_f = "Неопределенно";
            pay_for_t = 0;
            mas = 0;
            type_g = 'N';
            num_s = 0;
            num_m = 0;
            adr_from = "";
            adr_to = "";
        }

        /// <summary>
        /// Добавление в коллекцию
        /// </summary>
        /// <param name="tr">Добавляемый объект</param>
        /// <returns>Добавляемый объект</returns>
        public void AddToCol()
        {
            stackTr.Push(this);
            Added?.Invoke(this, new CompanyEventArgs($"Добавлена компания: '{name_f}'!"));
        }

        /// <summary>
        /// Удаление из коллекции
        /// </summary>
        /// <param name="tr">Удаляемый  объект</param>
        /// <returns>Удаляемый объект</returns>
        public void DeletFromCol()
        {

            Deleted?.Invoke(this, new CompanyEventArgs($"Удалена компания: '{stackTr.First().name_f}'!"));
            stackTr.Pop();
        }

        /// <summary>
        /// Преобразование объекта в массив string
        /// </summary>
        /// <returns>Массив string со всеми полями объекта</returns>
        public new string[] ToString()
        {
            string[] row = new string[8];
            row[0] = name_f;
            row[1] = Convert.ToString(pay_for_t);
            row[2] = Convert.ToString(mas);
            row[3] = Convert.ToString(type_g);
            row[4] = Convert.ToString(num_s);
            row[5] = Convert.ToString(num_m);
            row[6] = adr_from;
            row[7] = adr_to;

            return row;
        }
    }

}
