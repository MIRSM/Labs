﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratornaya_rabota_2
{
    class FG
    {
        public String name_f;//Название фирмы
        public double pay_for_t;//Оплата за тонну
        public int mas;//Масса груза
        public char type_g;//Класс груза (опасный/ценный/обычный)
        public int num_s;//Количество грузчиков
        public int num_m;//Количество машин для перевозки
        public String adr_from;//Адрес перевозки
        public String adr_to;//Адрес перевозки

        public FG()
        {
            name_f = "Неопределено";
            pay_for_t = 0;
            mas = 0;
            type_g = 'N';
            num_s = 0;
            num_m = 0;
            adr_from = "";
            adr_to = "";
        }
        public FG(String adr_t)
        {
            name_f = "Лёгкий груз";
            pay_for_t = 0;
            mas = 0;
            type_g = 'N';
            num_s = 0;
            num_m = 0;
            adr_from = "Перевозка производится со склада фирмы(Адресс фирмы)";
            adr_to = adr_t;
        }
        public FG(String adr_f, String adr_t)
        {

            Random r = new Random();
            name_f = "Лёгкий груз";
            pay_for_t = 1010.99;
            mas = r.Next(1, 15);
            type_g = 'N';
            num_s = r.Next(2, 4);
            num_m = r.Next(1, 3);
            adr_from = adr_f;
            adr_to = adr_t;
        }
        public FG(String n, double pay, int m, char tg, int ns, int nc, String af, String at)
        {
            name_f = n;
            pay_for_t = pay;
            mas = m;
            type_g = tg;
            num_s = ns;
            num_m = nc;
            adr_from = af;
            adr_to = at;
        }
        public void print_field(Char a)
        {
            switch (a)
            {
                case '1':
                    Console.WriteLine("\nНазвание фирмы:  \t\t\t" + name_f);
                    break;
                case '2':
                    Console.WriteLine("\nЦена за тонну груза:  \t\t\t" + pay_for_t);
                    break;
                case '3':
                    Console.WriteLine("\nМасса груза:  \t\t\t" + mas);
                    break;
                case '4':
                    Console.WriteLine("\nКласс груза:  \t\t\t" + type_g);
                    break;
                case '5':
                    Console.WriteLine("\nКоличество грузчиков:  \t\t\t" + num_s);
                    break;
                case '6':
                    Console.WriteLine("\nКоличество машин:  \t\t\t" + num_m);
                    break;
                case '7':
                    Console.WriteLine("\nАдрес погрузки:  \t\t\t" + adr_from);
                    break;
                case '8':
                    Console.WriteLine("\nАдрес разгрузки:  \t\t\t" + adr_to);
                    break;
                default:
                    Console.WriteLine("Неверный ввод!");
                    break;
            }
        }
        public override String ToString()
        {
            String tStr = "\nНазвание фирмы:  \t\t\t" + name_f;
            if (pay_for_t == 0) tStr += "\nЦена за тонну груза:  \t\t\tНеопределено";
            else tStr += "\nЦенa за тонну груза:  \t\t\t" + pay_for_t;
            if (mas == 0) tStr += "\nМасса груза:  \t\t\t\tНеопределно";
            else tStr += "\nМасса груза:  \t\t\t\t" + mas;
            tStr += "\nВид груза(D-опасный/V-ценный/N-обычный): " + type_g;
            if (num_s == 0) tStr += "\nKол-во рабочих:  \t\t\tНеопределено";
            else tStr += "\nKол-во рабочих:  \t\t\t" + num_s;
            if (num_m == 0) tStr += "\nKол-во машин для перевозки:  \t\tНеопределно";
            else tStr += "\nKол-во машин для перевозки:  \t\t" + num_m;
            if (adr_from == "") tStr += "\nAдресс погрузки:  \t\t\t" + adr_from;
            else tStr += "\nAдресс погрузки:  \t\t\t" + adr_from;
            if (adr_to == "") tStr += "\nAдресс выгрузки:  \t\t\tНеопределено \n";
            else tStr += "\nAдресс выгрузки:  \t\t\t" + adr_to + "\n";
            return tStr;
        }
    }
}
