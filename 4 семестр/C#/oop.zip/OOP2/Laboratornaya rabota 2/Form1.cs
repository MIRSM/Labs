﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Laboratornaya_rabota_2
{

    public partial class Form1 : Form
    {
        static List<FG> dgv = dgv = new List<FG>();
        public Form1()
        {
            InitializeComponent();
            num_d.Text = "" + dgv.Count;
            if (dgv.Count == 0)
            {
                num_d_in.Enabled = false;
                showInf.Enabled = false;
            }
            Console.Beep();
        }
        private bool checkTB()
        {
            bool f = false;
            if (textBox1.Text == "")
            {
                f = true;
                textBox1.BackColor = Color.LightCoral;
            }
            else textBox1.BackColor = Color.White;
            if (textBox2.Text == "")
            {
                f = true;
                textBox2.BackColor = Color.LightCoral;
            }
            else textBox2.BackColor = Color.White;
            if (textBox3.Text == "")
            {
                f = true;
                textBox3.BackColor = Color.LightCoral;
            }
            else textBox3.BackColor = Color.White;
            if (textBox4.Text == "")
            {
                f = true;
                textBox4.BackColor = Color.LightCoral;
            }
            else textBox4.BackColor = Color.White;
            if (textBox5.Text == "")
            {
                f = true;
                textBox5.BackColor = Color.LightCoral;
            }
            else textBox5.BackColor = Color.White;
            if (textBox6.Text == "")
            {
                f = true;
                textBox6.BackColor = Color.LightCoral;
            }
            else textBox6.BackColor = Color.White;
            if (textBox7.Text == "")
            {
                f = true;
                textBox7.BackColor = Color.LightCoral;
            }
            else textBox7.BackColor = Color.White;
            if (textBox8.Text == "")
            {
                f = true;
                textBox8.BackColor = Color.LightCoral;
            }
            else textBox8.BackColor = Color.White;
            return f;
        }

        private bool readF(ref String n_f, ref double f_ton, ref int ton, ref char kind, ref int n_s, ref int n_c, ref String a_f, ref String a_t)
        {
            bool f = true;
            n_f = textBox1.Text;//Название фирмы

            //Цена за тонну
            f_ton = 0.0;
            try
            {
                f_ton = Convert.ToDouble(textBox2.Text);
                if (f_ton <= 0)
                {
                    MessageBox.Show("Неверный ввод данных в поле 'Цена за тонну'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    f = false;
                }
            }
            catch
            {
                MessageBox.Show("Неверный ввод данных в поле 'Цена за тонну'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                f = false;
            }

            //Масса груза
            ton = 0;
            try
            {
                ton = Convert.ToInt32(textBox3.Text);
                if (ton <= 0)
                {
                    MessageBox.Show("Неверный ввод данных в поле 'Масса груза'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    f = false;
                }
            }
            catch
            {
                MessageBox.Show("Неверный ввод данных в поле 'Масса груза'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                f = false;
            }

            //Класс груза
            kind = '\0';
            try
            {
                kind = Convert.ToChar(textBox4.Text.ToLowerInvariant());
                if (kind != 'd' && kind != 'v' && kind != 'n')
                {
                    MessageBox.Show("Неверный ввод данных в поле 'Класс груза'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    f = false;
                }
            }
            catch
            {
                MessageBox.Show("Неверный ввод данных в поле 'Класс груза'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                f = false;
            }

            //Количество грузчиков
            n_s = -1;
            try
            {
                n_s = Convert.ToInt32(textBox5.Text);
                if (n_s < 0)
                {
                    MessageBox.Show("Неверный ввод данных в поле 'Количество грузчиков'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    f = false;
                }
            }
            catch
            {
                MessageBox.Show("Неверный ввод данных в поле 'Количество грузчиков'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                f = false;
            }

            //Количество машин
            n_c = -1;
            try
            {
                n_c = Convert.ToInt32(textBox6.Text);
                if (n_c < 0)
                {
                    MessageBox.Show("Неверный ввод данных в поле 'Количество машин'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    f = false;
                }
            }
            catch
            {
                MessageBox.Show("Неверный ввод данных в поле 'Количество машин'", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                f = false;
            }

            a_f = textBox7.Text;//Адрес погрузки
            a_t = textBox8.Text;//Адрес разгрузки
            return f;
        }

        //Сохранение нового объекта
        private void made_d_Click(object sender, EventArgs e)
        {
            FG d = null;
            if (checkTB())
            {
                MessageBox.Show("Не все поля заполнены", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                textBox1.BackColor = Color.White;
                textBox2.BackColor = Color.White;
                textBox3.BackColor = Color.White;
                textBox4.BackColor = Color.White;
                textBox5.BackColor = Color.White;
                textBox6.BackColor = Color.White;
                textBox7.BackColor = Color.White;
                textBox8.BackColor = Color.White;

                String n_f=""; double f_ton=0.0; int ton=0; char kind='\0'; int n_s=0; int n_c=0; String a_f=""; String a_t="";

                
                bool f = readF(ref n_f, ref f_ton, ref ton, ref kind, ref n_s, ref n_c, ref a_f, ref a_t);

                if (f == true)
                {
                    d = new FG(n_f, f_ton, ton, kind, n_s, n_c, a_f, a_t);
                    dgv.Add(d);
                    num_d.Text = "" + dgv.Count;
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox6.Clear();
                    textBox7.Clear();
                    textBox8.Clear();
                    MessageBox.Show("Объект создан", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                if (dgv.Count != 0)
                {
                    num_d_in.Enabled = true;
                    showInf.Enabled = true;
                }
            }
        }

        //Показать объект
        private void showInf_Click(object sender, EventArgs e)
        {
            if (num_d_in.Text != "")
            {
                int i = Convert.ToInt32(num_d_in.Text);
                Console.WriteLine(i + "   " + dgv.Count);
                if (i > 0 && i <= dgv.Count)
                {
                    FG d = dgv[i - 1];
                    textBox1.Text = d.name_f;
                    textBox2.Text = "" + d.pay_for_t;
                    textBox3.Text = "" + d.mas;
                    textBox4.Text = "" + d.type_g;
                    textBox5.Text = "" + d.num_s;
                    textBox6.Text = "" + d.num_m;
                    textBox7.Text = d.adr_from;
                    textBox8.Text = d.adr_to;
                    save_d.Enabled = true;
                    showInf.Enabled = false;
                    made_d.Enabled = false;
                    num_d_in.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Неверны ввод", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else MessageBox.Show("Поле пустое", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        //Сохранение изменений
        private void save_d_Click(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(num_d_in.Text);
            if (checkTB())
            {
                MessageBox.Show("Не все поля заполнены", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                textBox1.BackColor = Color.White;
                textBox2.BackColor = Color.White;
                textBox3.BackColor = Color.White;
                textBox4.BackColor = Color.White;
                textBox5.BackColor = Color.White;
                textBox6.BackColor = Color.White;
                textBox7.BackColor = Color.White;
                textBox8.BackColor = Color.White;

                String n_f = ""; double f_ton = 0.0; int ton = 0; char kind = '\0'; int n_s = 0; int n_c = 0; String a_f = ""; String a_t = "";


                bool f = readF(ref n_f, ref f_ton, ref ton, ref kind, ref n_s, ref n_c, ref a_f, ref a_t);

                if (f == true)
                {
                    FG d = new FG(n_f, f_ton, ton, kind, n_s, n_c, a_f, a_t);
                    dgv[i-1]=d;
                    num_d.Text = "" + dgv.Count;
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox6.Clear();
                    textBox7.Clear();
                    textBox8.Clear();
                    MessageBox.Show("Объект сохранен", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                made_d.Enabled = true;
                if (dgv.Count != 0)
                {
                    num_d_in.Enabled = true;
                    showInf.Enabled = true;
                }
            }
        }
    }
}
