﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_2
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void buttonStartCompile_Click(object sender, EventArgs e)
        {
            Lexer lex = new Lexer(txtCode.Text);
            Parser pars = new Parser(lex.TOKENS);
            txtMsg.Text = pars.DebugMsg + "\n";
        }
    }
}
