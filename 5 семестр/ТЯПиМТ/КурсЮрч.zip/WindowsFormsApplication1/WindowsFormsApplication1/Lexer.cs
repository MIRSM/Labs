﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace WindowsFormsApplication1
{
    internal class Lexer
    {
        private const int IdentLength = 12;
        private string Code;
        private int FindInt = 0;
        public string Error = "";
        public int kolError = 0;

        private struct KeyWords
        {
            public string Words;
            public string WordKey;

            public KeyWords(string a, string b)
            {
                Words = a;
                WordKey = b;
            }

        }

        private KeyWords[] KEYS =
        {
            new KeyWords("VAR", "01"), new KeyWords("INTEGER", "02"), new KeyWords("BEGIN", "03"),
            new KeyWords("END", "04"), new KeyWords("READ", "05"), new KeyWords("WRITE", "06"),
            new KeyWords("CASE", "07"), new KeyWords("OF", "08"), new KeyWords("END_CASE", "09")
        };

        private KeyWords[] CHARS =
        {
            new KeyWords(":", "10"), new KeyWords(";", "11"), new KeyWords("=", "12"),
            new KeyWords("+", "13"), new KeyWords("-", "14"), new KeyWords("/", "15"),
            new KeyWords("(", "16"), new KeyWords(")", "17"), new KeyWords(",", "18")
        };


        /*
            Недопустимый символ 91
            Слишком длинное имя переменной 92
            Повторное объявление переменной 93
            Необъявленная переменная 94
            Неверное имя переменной 95 
        */


        //регулярное выражение
        private string rgz = @"(?<char>[^:;\(\)\=\+\-\/\s\,]*)(?<separator>[:;\(\)\=\+\-\/\s\,]{1})?";

        //список полученных токенов, идентификаторов, констант
        public Stack<string> TOKENS = new Stack<string>();
        public List<string> IDENTIFIES = new List<string>();
        public List<string> CONSTANTS = new List<string>();

        public Lexer()
        {
            this.Error = "Lexer error.\n";
        }

        public Lexer(string Code)
        {
            this.Code = Code;
            string pattern = "( )+";
            string replacement = " ";
            if (this.Code.Length == 0)
            {
                this.Error += "Error: No entry.\n";
            }
            else
            {
                //удаление лишних пробелов, перевод в вверхний регистр
                Regex rgx = new Regex(pattern);
                this.Code = rgx.Replace(this.Code, replacement);
                this.Code = this.Code.ToUpper();
            }
            LexerOut();
        }

        private void LexerOut()
        {
            Match match = Regex.Match(this.Code, this.rgz);
            while (match.Success)
            {
                if (match.Groups["char"].Length > 0)
                    if (!IsKeyword(match.Groups["char"].ToString(), KEYS))
                        if (!IsIdenOrConst(match.Groups["char"].ToString(),
                            "[^0-9]+", "21", CONSTANTS, int.MaxValue.ToString().Length))
                        {
                            IDENTIFIES.Add(match.Groups["char"].ToString());
                            AddError(match.Groups["char"].ToString());
                        }
                if ((match.Groups["separator"].ToString() != " ") && (match.Groups["separator"].ToString() != "\n"))
                    IsKeyword(match.Groups["separator"].ToString(), CHARS);
                match = match.NextMatch();
            }
        }

        private bool IsKeyword(string word, KeyWords[] kwd)
        {
            bool TOF = false;
            for (int i = 0; i < kwd.Count(); i++)
            {
                if (kwd[i].Words == word)
                {
                    TOKENS.Push(kwd[i].WordKey);
                    TOF = true;
                    if (word == "BEGIN")
                        FindInt = IDENTIFIES.Count;
                    break;
                }
            }
            return TOF;
        }


        private bool IsIdenOrConst(string word, string regular, string ID, List<string> lst, int len)
        {
            bool TOF = true;
            if (Regex.Match(word, regular).Success)
                TOF = false;
            else
            {
                TOKENS.Push(ID);
                lst.Add(word);
            }
            return TOF;
        }

        private void AddError(string word)
        {
            int kol = 0;
            for (int i = 0; i < 5; i++)
            {
                switch (i)
                {
                    case 0: { if (Regex.Match(word, @"[^A-Z0-9:;\(\)\=\+\-\/\s\,]").Success) { kol++; TOKENS.Push("91"); } break; }
                    case 1: { if (word.Length > IdentLength) { kol++; TOKENS.Push("92"); } break; }
                    case 2: { int k2 = 0; if (FindInt == 0) for (int j = 0; j < IDENTIFIES.Count; j++) if (word == IDENTIFIES[j]) k2++; if (k2 > 1) { kol++; TOKENS.Push("93"); } break; }
                    case 3: { int k2 = 1; if (FindInt != 0) { k2 = 0; for (int j = 0; j < FindInt; j++) if (word == IDENTIFIES[j]) k2++; } if (k2 == 0) { kol++; TOKENS.Push("94"); } break; }
                    case 4: { if (Regex.Match(word, "[^A-Z]").Success) { kol++; TOKENS.Push("95"); } break; }
                }
            }
            if (kol == 0)
                TOKENS.Push("20");
        }
    }

}
