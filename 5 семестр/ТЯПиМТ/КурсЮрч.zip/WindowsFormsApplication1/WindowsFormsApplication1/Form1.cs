﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int len = 0;
        private static bool IsEnter = false;
        private static string ReadString = "";

        private delegate void AddText(string msg);

        private delegate void IsVisible(bool msg);

        private struct snd
        {
            public List<Stack<string>> IN;
            public RichTextBox rtb;

            public snd(List<Stack<string>> a, RichTextBox b)
            {
                IN = a;
                rtb = b;
            }
        };

        private struct ConstIdent
        {
            public string Ident;
            public string Const;

            public ConstIdent(string a, string b)
            {
                Ident = a;
                Const = b;
            }
        };

        private struct CaseStruct
        {
            public int one;
            public string two;
            public string three;

            public CaseStruct(int a, string b, string c)
            {
                one = a;
                two = b;
                three = c;
            }
        };

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void сохранитьФайлToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sd = new SaveFileDialog();
            sd.DefaultExt = "*.compiler";
            sd.Filter = "RT files(*.compiler)|*.compiler";
            if (sd.ShowDialog() == DialogResult.OK && sd.FileName.Length > 0)
            {
                txtCode.SaveFile(sd.FileName, RichTextBoxStreamType.PlainText);
            }
        }

        private void создатьПроектToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtCode.Text = "";
            txtMsg.Text = "";
        }

        private void открытьФайлToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog OpnFDlg = new OpenFileDialog())
            {
                try
                {
                    OpnFDlg.Filter = "RT files(*.compiler)|*.compiler|All files(*.*)|*.*";
                    OpnFDlg.FilterIndex = 1;
                    OpnFDlg.InitialDirectory = "C:\\Desktop";
                    if (OpnFDlg.ShowDialog() == DialogResult.OK)
                    {
                        StreamReader sr = new StreamReader(OpnFDlg.FileName, Encoding.Default);
                        string str = sr.ReadToEnd();
                        sr.Close();
                        txtCode.Text = str;
                    }
                }
                catch (Exception msg)
                {
                    MessageBox.Show(msg.Message);
                }
            }
        }

        private void runToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Lexer lex = new Lexer(txtCode.Text);
            Parser pars = new Parser(lex.TOKENS);
            if (pars.DebugMsg == "DEBUGGED")
            {
                txtMsg.Focus();
                Shell shell = new Shell(pars.TokensShell, lex.IDENTIFIES, lex.CONSTANTS);
                snd[] snd1 = {new snd(shell.OUT, txtMsg)};
                Thread RunThread = new Thread(Run);
                RunThread.Start(snd1);
            }
            txtMsg.Text = pars.DebugMsg + "\n";
        }

        private static void Run(object INI)
        {
            snd[] snd1 = (snd[]) INI;
            List<ConstIdent> CI = new List<ConstIdent>();
            for (int i = 0; i < snd1[0].IN.Count(); i++)
            {
                while (snd1[0].IN[i].Count() != 0)
                {
                    switch (snd1[0].IN[i].Peek())
                    {
                        case "05":
                        {
                            if (snd1[0].rtb.InvokeRequired)
                                snd1[0].rtb.Invoke(new IsVisible((s) => snd1[0].rtb.ReadOnly = s), false);

                            snd1[0].IN[i].Pop();
                            snd1[0].rtb.Invoke(new AddText((s) => snd1[0].rtb.AppendText(s)), "ENTER DATA\n");

                            while (snd1[0].IN[i].Count != 0)
                            {
                                int rr = 0;
                                string b = "";
                                string a = snd1[0].IN[i].Pop();
                                snd1[0].rtb.Invoke(new AddText((s) => snd1[0].rtb.AppendText(s)), a + " = ");
                                    
                                while (rr == 0)
                                {
                                    while (IsEnter == false)
                                    {
                                        Thread.Sleep(100);
                                    }

                                    b = ReadString;
                                    b = b.Substring(a.Length + 2);

                                    try
                                    {
                                        int k = Convert.ToInt32(b);
                                        IsEnter = false;
                                        rr++;
                                    }
                                    catch
                                    {
                                        if (snd1[0].rtb.InvokeRequired)
                                            snd1[0].rtb.Invoke(new AddText((s) => snd1[0].rtb.AppendText(s)),
                                                "Incorrect type\n" + a + " = ");
                                        IsEnter = false;
                                    }
                                }
                                CI.Add(new ConstIdent(a, b));
                            }
                            IsEnter = false;
                            if (snd1[0].rtb.InvokeRequired)
                                snd1[0].rtb.Invoke(new IsVisible((s) => snd1[0].rtb.ReadOnly = s), true);

                            break;
                        }
                        case "06":
                        {
                            snd1[0].rtb.Invoke(new AddText((s) => snd1[0].rtb.AppendText(s)), "OUTPUT DATA\n");
                            snd1[0].IN[i].Pop();

                            while (snd1[0].IN[i].Count != 0)
                            {
                                for (int j = CI.Count - 1; j >= 0; j--)
                                {
                                    if (snd1[0].IN[i].Peek() == CI[j].Ident)
                                    {
                                        try
                                        {
                                            Convert.ToInt32(CI[j].Const);
                                            if (snd1[0].rtb.InvokeRequired)
                                                snd1[0].rtb.Invoke(new AddText((s) => snd1[0].rtb.AppendText(s)),
                                                    Convert.ToString(CI[j].Ident + " = " + CI[j].Const + "\n"));
                                        }
                                        catch
                                        {
                                            if (snd1[0].rtb.InvokeRequired)
                                                snd1[0].rtb.Invoke(new AddText((s) => snd1[0].rtb.AppendText(s)), "");
                                        }
                                        snd1[0].IN[i].Pop();
                                        break;
                                    }
                                }
                            }
                            break;
                        }
                        case "07":
                        {
                            Stack<string> s1 = new Stack<string>();
                            List<CaseStruct> CS = new List<CaseStruct>();
                            string three;
                            int case1 = 0;
                            snd1[0].IN[i].Pop();
                            snd1[0].IN[i].Pop();
                            string case2 = snd1[0].IN[i].Pop();
                            if (snd1[0].IN[i].Peek() == "$")
                            {
                                try
                                {
                                    case1 = Convert.ToInt32(case2);
                                }
                                catch
                                {
                                    try
                                    {
                                        case1 = Convert.ToInt32(TryFind(case2, CI));
                                    }
                                    catch
                                    {
                                        if (snd1[0].rtb.InvokeRequired)
                                            snd1[0].rtb.Invoke(new AddText((s) => snd1[0].rtb.AppendText(s)),
                                                TryFind(case2, CI) + "\n");
                                    }
                                }
                            }
                            else
                            {
                                snd1[0].IN[i].Push(case2);
                                try
                                {
                                    case1 = Convert.ToInt32(Operation(snd1[0].IN[i], CI));
                                }
                                catch
                                {
                                    if (snd1[0].rtb.InvokeRequired)
                                        snd1[0].rtb.Invoke(new AddText((s) => snd1[0].rtb.AppendText(s)),
                                            Operation(snd1[0].IN[i], CI) + "\n");
                                }
                            }
                            snd1[0].IN[i].Pop();
                            while (snd1[0].IN[i].Count != 0)
                            {
                                int one = Convert.ToInt32(snd1[0].IN[i].Pop());
                                string two = snd1[0].IN[i].Pop();
                                snd1[0].IN[i].Pop();
                                three = Operation(snd1[0].IN[i], CI);
                                CS.Add(new CaseStruct(one, two, three));
                                snd1[0].IN[i].Pop();
                            }
                            for (int j = 0; j < CS.Count; j++)
                            {
                                if (case1 == CS[j].one)
                                {
                                    CI.Add(new ConstIdent(CS[j].two, CS[j].three));
                                    break;
                                }
                            }
                            break;
                        }
                        default:
                        {
                            if (snd1[0].IN[i].Count() == 4)
                            {
                                string a = snd1[0].IN[i].Pop();
                                snd1[0].IN[i].Pop();
                                string err = TryFind(snd1[0].IN[i].Pop(), CI);
                                CI.Add(new ConstIdent(a, err));
                                snd1[0].IN[i].Pop();
                                break;
                            }
                            else
                            {
                                string a = snd1[0].IN[i].Pop();
                                snd1[0].IN[i].Pop();
                                string ww = Operation(snd1[0].IN[i], CI);
                                if (ww == "variable is not set" || ww == "zero division")
                                    if (snd1[0].rtb.InvokeRequired)
                                        snd1[0].rtb.Invoke(new AddText((s) => snd1[0].rtb.AppendText(s)), ww + "\n");
                                CI.Add(new ConstIdent(a, ww));
                                snd1[0].IN[i].Pop();
                            }
                            break;
                        }
                    }
                }
            }
            snd1[0].rtb.Invoke(new AddText((s) => snd1[0].rtb.AppendText(s)), "COMPILATOR WORKED\n");
        }

        private static string TryFind(string a, List<ConstIdent> ci)
        {
            int ret;
            int kol = 0;
            while (true)
            {
                try
                {
                    ret = Convert.ToInt32(a);
                    return a;
                }
                catch
                {
                    kol = 0;
                    for (int j = ci.Count - 1; j >= 0; j--)
                    {
                        if (ci[j].Ident == a)
                        {
                            a = ci[j].Const;
                            kol++;
                            break;
                        }
                    }
                    if (kol == 0)
                        return "variable is not set";
                }
            }
        }


        private static string Operation(Stack<string> a, List<ConstIdent> CI)
        {
            Stack<string> s1 = new Stack<string>();
            while (a.Peek() != "$")
            {
                switch (a.Peek())
                {
                    case "+":
                    {
                        a.Pop();
                        int b1, c1;
                        try
                        {
                            b1 = Convert.ToInt32(TryFind(s1.Pop(), CI));
                            c1 = Convert.ToInt32(TryFind(s1.Pop(), CI));
                        }
                        catch
                        {
                            return "variable is not set";
                        }
                        if (a.Peek() != "$")
                            s1.Push(Convert.ToString(b1 + c1));
                        else
                            return Convert.ToString(b1 + c1);
                        break;
                    }
                    case "-":
                    {
                        a.Pop();
                        int b1, c1;
                        try
                        {
                            b1 = Convert.ToInt32(TryFind(s1.Pop(), CI));
                            c1 = Convert.ToInt32(TryFind(s1.Pop(), CI));
                        }
                        catch
                        {
                            return "variable is not set";
                        }
                        if (a.Peek() != "$")
                            s1.Push(Convert.ToString(c1 - b1));
                        else
                            return Convert.ToString(c1 - b1);
                        break;
                    }
                    case "/":
                    {
                        a.Pop();
                        int b1, c1;
                        try
                        {
                            b1 = Convert.ToInt32(TryFind(s1.Pop(), CI));
                            c1 = Convert.ToInt32(TryFind(s1.Pop(), CI));
                            if (b1 == 0)
                                return "zero division";
                        }
                        catch
                        {
                            return "variable is not set";
                        }
                        if (a.Peek() != "$")
                            s1.Push(Convert.ToString(c1/b1));
                        else
                            return Convert.ToString(c1/b1);
                        break;
                    }
                    default:
                    {
                        s1.Push(a.Pop());
                        if (a.Peek() == "$" && s1.Count == 1)
                        {
                            return s1.Pop();
                        }
                        break;
                    }
                }
            }
            return "error";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void txtCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (int) Keys.Control || e.KeyValue == (int) Keys.E || e.KeyValue == (int) Keys.J ||
                e.KeyValue == (int) Keys.R)
            {
                e.Handled = true;
            }

        }

        private void txtMsg_KeyDown(object sender, KeyEventArgs e)
        
       {
            if (e.KeyValue == (int) Keys.Control || e.KeyValue == (int) Keys.E || e.KeyValue == (int) Keys.J ||
                e.KeyValue == (int) Keys.R || e.KeyValue == (int) Keys.Z)
            {
                e.Handled = true;
            }
            if (e.KeyValue == (int) Keys.Control || e.KeyValue == (int) Keys.A)
            {
                e.Handled = true;
                int k = txtMsg.Text.Length - txtMsg.GetFirstCharIndexOfCurrentLine();
                txtMsg.Select(txtMsg.GetFirstCharIndexOfCurrentLine(), k);
                txtMsg.Refresh();
            }
            if (e.KeyValue == (int) Keys.Control || e.KeyValue == (int) Keys.Home)
            {
                e.Handled = true;
            }
            if (e.KeyValue == (int) Keys.Up || e.KeyValue == (int) Keys.Down)
            {
                e.Handled = true;
            }
            if (e.KeyValue == (int) Keys.Left)
            {
                if (txtMsg.SelectionStart <= len)
                {
                    e.Handled = true;
                }
            }
            if (e.KeyValue == (int) Keys.PageDown || e.KeyValue == (int) Keys.PageUp)
            {
                e.Handled = true;
            }
            if (e.KeyValue == (int) Keys.Back)
            {
                if (txtMsg.SelectionStart <= len)
                {
                    e.Handled = true;
                }
            }
            if (e.KeyValue == (int) Keys.Enter)
            {
                if (txtMsg.ReadOnly == false)
                {
                    ReadString =
                        txtMsg.Lines[
                            txtMsg.GetLineFromCharIndex(txtMsg.GetFirstCharIndexFromLine(txtMsg.SelectionStart - 1))];
                    IsEnter = true;
                }
                len = txtMsg.SelectionStart = txtMsg.Text.Length + 1;
            }
        }


    }
}



    



