﻿namespace Lab_1
{
    partial class Main
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCode = new System.Windows.Forms.RichTextBox();
            this.txtMsg = new System.Windows.Forms.RichTextBox();
            this.buttonStartCompile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtCode
            // 
            this.txtCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtCode.Location = new System.Drawing.Point(12, 12);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(648, 369);
            this.txtCode.TabIndex = 0;
            this.txtCode.Text = "var\na,b:integer;\nbegin\nread(a);\nb=a+100;\nwrite(a,b);\nend";
            // 
            // txtMsg
            // 
            this.txtMsg.Location = new System.Drawing.Point(12, 387);
            this.txtMsg.Name = "txtMsg";
            this.txtMsg.ReadOnly = true;
            this.txtMsg.Size = new System.Drawing.Size(648, 155);
            this.txtMsg.TabIndex = 1;
            this.txtMsg.Text = "";
            // 
            // buttonStartCompile
            // 
            this.buttonStartCompile.Location = new System.Drawing.Point(12, 548);
            this.buttonStartCompile.Name = "buttonStartCompile";
            this.buttonStartCompile.Size = new System.Drawing.Size(648, 35);
            this.buttonStartCompile.TabIndex = 2;
            this.buttonStartCompile.Text = "Проверить";
            this.buttonStartCompile.UseVisualStyleBackColor = true;
            this.buttonStartCompile.Click += new System.EventHandler(this.buttonStartCompile_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 595);
            this.Controls.Add(this.buttonStartCompile);
            this.Controls.Add(this.txtMsg);
            this.Controls.Add(this.txtCode);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lab 1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtCode;
        private System.Windows.Forms.RichTextBox txtMsg;
        private System.Windows.Forms.Button buttonStartCompile;
    }
}

