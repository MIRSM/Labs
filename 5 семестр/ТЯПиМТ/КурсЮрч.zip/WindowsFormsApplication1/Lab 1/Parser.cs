﻿using System.Collections.Generic;

namespace Lab_1
{
    class Parser
    {
        private Stack<string> Tokens = new Stack<string>();
        private Stack<string> TokensStack = new Stack<string>();
        private Stack<string> StatesStack = new Stack<string>();
        public string DebugMsg = "";
        public Stack<string> TokensShell = new Stack<string>();
        public Parser(Stack<string> Tokens)
        {
            this.Tokens = Tokens;
            Parsing();
        }
        //создаем список состояний
        string[,] States = { { "04", "53", "03", "11", "02", "10", "51", "00" },
                             { "54", "11", "17", "51", "16", "00", "00", "00" },
                             { "54", "11", "09", "56", "08", "58", "00", "00" },
                             { "54", "11", "58", "12", "00", "00", "00", "00" },
                             { "11", "58", "12", "00", "00", "00", "00", "00" },
                             { "57", "55", "10", "00", "00", "00", "00", "00" },
                             { "60", "17", "58", "00", "00", "00", "00", "00" } };
        //записываем лексемы в стек
        private void ToStack()
        {
            TokensStack.Push("$");
            TokensShell.Push("$");
            while (Tokens.Count != 0)
            {
                TokensStack.Push(Tokens.Peek());
                TokensShell.Push(Tokens.Pop());
            }
        }
        //парсер
        private int Parsing()
        {
            ToStack();
            StatesStack.Push("$");
            StatesStack.Push("50");
            while ((StatesStack.Count != 0) || (TokensStack.Count != 0))
            {
                switch (StatesStack.Pop())
                {
                    case "50":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "01": { int i = 0; while (States[0, i] != "00") StatesStack.Push(States[0, i++]); break; }
                                default: { DebugMsg = "error: expected \"VAR\""; return 0; }
                            }
                            break;
                        }
                    case "51":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "20": { StatesStack.Push("52"); break; }
                                case "91": { DebugMsg = "error: invalid code"; return 0; }
                                case "92": { DebugMsg = "error: long variable name"; return 0; }
                                case "93": { DebugMsg = "error: re variable declaration"; return 0; }
                                case "94": { DebugMsg = "error: undeclared variable"; return 0; }
                                case "95": { DebugMsg = "error: incorrect variable name"; return 0; }
                                default: { DebugMsg = "error: expected variable"; return 0; }
                            }
                            break;
                        }
                    case "52":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "18": { StatesStack.Push("51"); break; }
                                case "10": { StatesStack.Pop(); break; }
                                case "17": { StatesStack.Pop(); break; }
                                default: { DebugMsg = "error: Syntax error"; return 0; }
                            }
                            break;
                        }
                    case "53":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "05": { int i = 0; while (States[1, i] != "00") StatesStack.Push(States[1, i++]); break; }
                                case "06": { int i = 0; while (States[1, i] != "00") StatesStack.Push(States[1, i++]); break; }
                                case "07": { int i = 0; while (States[2, i] != "00") StatesStack.Push(States[2, i++]); break; }
                                case "20": { int i = 0; while (States[3, i] != "00") StatesStack.Push(States[3, i++]); break; }
                                case "91": { DebugMsg = "error: invalid code"; return 0; }
                                case "92": { DebugMsg = "error: long variable name"; return 0; }
                                case "93": { DebugMsg = "error: re variable declaration"; return 0; }
                                case "94": { DebugMsg = "error: undeclared variable"; return 0; }
                                case "95": { DebugMsg = "error: incorrect variable name"; return 0; }
                                default: { DebugMsg = "error: Syntax error"; return 0; }
                            }
                            break;
                        }
                    case "54":
                        {
                            switch (TokensStack.Peek())
                            {
                                case "05": { StatesStack.Push("53"); break; }
                                case "06": { StatesStack.Push("53"); break; }
                                case "07": { StatesStack.Push("53"); break; }
                                case "20": { StatesStack.Push("53"); break; }
                                case "04": { StatesStack.Pop(); TokensStack.Pop(); break; }
                                case "91": { DebugMsg = "error: invalid code"; return 0; }
                                case "92": { DebugMsg = "error: long variable name"; return 0; }
                                case "93": { DebugMsg = "error: re variable declaration"; return 0; }
                                case "94": { DebugMsg = "error: undeclared variable"; return 0; }
                                case "95": { DebugMsg = "error: incorrect variable name"; return 0; }
                                default: { DebugMsg = "error: Syntax error"; return 0; }
                            }
                            break;
                        }
                    case "55":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "20": { int i = 0; while (States[4, i] != "00") StatesStack.Push(States[4, i++]); break; }
                                case "91": { DebugMsg = "error: invalid code"; return 0; }
                                case "92": { DebugMsg = "error: long variable name"; return 0; }
                                case "93": { DebugMsg = "error: re variable declaration"; return 0; }
                                case "94": { DebugMsg = "error: undeclared variable"; return 0; }
                                case "95": { DebugMsg = "error: incorrect variable name"; return 0; }
                                default: { DebugMsg = "error: Syntax error"; return 0; }
                            }
                            break;
                        }
                    case "56":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "21": { int i = 0; while (States[5, i] != "00") StatesStack.Push(States[5, i++]); break; }
                                default: { DebugMsg = "error: Syntax error"; return 0; }
                            }
                            break;
                        }
                    case "57":
                        {
                            switch (TokensStack.Peek())
                            {
                                case "21": { StatesStack.Push("56"); break; }
                                case "09": { TokensStack.Pop(); break; }
                                default: { DebugMsg = "error: Syntax error"; return 0; }
                            }
                            break;
                        }
                    case "58":
                        {
                            switch (TokensStack.Peek())
                            {
                                case "14": { TokensStack.Pop(); StatesStack.Push("59"); break; }
                                case "16": { StatesStack.Push("59"); break; }
                                case "20": { StatesStack.Push("59"); break; }
                                case "21": { StatesStack.Push("59"); break; }
                                case "91": { DebugMsg = "error: invalid code"; return 0; }
                                case "92": { DebugMsg = "error: long variable name"; return 0; }
                                case "93": { DebugMsg = "error: re variable declaration"; return 0; }
                                case "94": { DebugMsg = "error: undeclared variable"; return 0; }
                                case "95": { DebugMsg = "error: incorrect variable name"; return 0; }
                                default: { DebugMsg = "error: incorrect expression"; return 0; }
                            }
                            break;
                        }

                    case "59":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "16": { int i = 0; while (States[6, i] != "00") StatesStack.Push(States[6, i++]); break; }
                                case "20": { StatesStack.Push("60"); break; }
                                case "21": { StatesStack.Push("60"); break; }
                                case "91": { DebugMsg = "error: invalid code"; return 0; }
                                case "92": { DebugMsg = "error: long variable name"; return 0; }
                                case "93": { DebugMsg = "error: re variable declaration"; return 0; }
                                case "94": { DebugMsg = "error: undeclared variable"; return 0; }
                                case "95": { DebugMsg = "error: incorrect variable name"; return 0; }
                                default: { DebugMsg = "error: Syntax error"; return 0; }
                            }
                            break;
                        }
                    case "60":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "13": { StatesStack.Push("59"); break; }
                                case "14": { StatesStack.Push("59"); break; }
                                case "15": { StatesStack.Push("59"); break; }
                                case "08": { StatesStack.Pop(); break; }
                                case "11": { StatesStack.Pop(); break; }
                                case "17": { StatesStack.Pop(); break; }
                                default: { DebugMsg = "error: Syntax error"; return 0; }
                            }
                            break;
                        }
                    case "02":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "02": { break; }
                                default: { DebugMsg = "error: expected \"integer\""; return 0; }
                            }
                            break;
                        }
                    case "03":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "03": { break; }
                                default: { DebugMsg = "error: expected \"begin\""; return 0; }
                            }
                            break;
                        }
                    case "11":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "11": { break; }
                                default: { DebugMsg = "error: expected \";\""; return 0; }
                            }
                            break;
                        }
                    case "12":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "12": { break; }
                                default: { DebugMsg = "error: expected \"=\""; return 0; }
                            }
                            break;
                        }
                    case "10":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "10": { break; }
                                default: { DebugMsg = "error: expected \":\""; return 0; }
                            }
                            break;
                        }
                    case "16":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "16": { break; }
                                default: { DebugMsg = "error: expected \"(\""; return 0; }
                            }
                            break;
                        }
                    case "17":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "17": { break; }
                                default: { DebugMsg = "error: expected \")\""; return 0; }
                            }
                            break;
                        }
                    case "$":
                        {
                            switch (TokensStack.Pop())
                            {
                                case "$": { break; }
                                default: { DebugMsg = "error: incorrect completion"; return 0; }
                            }
                            break;
                        }
                    default: { break; }
                }
            }
            DebugMsg = "DEBUGGED";
            return 0;
        }
    }
}
